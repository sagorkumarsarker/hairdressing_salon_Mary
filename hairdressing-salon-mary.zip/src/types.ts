export type Language = 'hr' | 'en';

export interface ServiceItem {
  id: string;
  title: {
    hr: string;
    en: string;
  };
  category: 'cuts' | 'grooming' | 'shaving' | 'styling' | 'care';
  description: {
    hr: string;
    en: string;
  };
  durationNote?: {
    hr: string;
    en: string;
  };
  iconName: string;
  badge?: {
    hr: string;
    en: string;
  };
}

export interface GalleryImage {
  id: string;
  url: string;
  alt: {
    hr: string;
    en: string;
  };
  category: 'interior' | 'styling' | 'grooming' | 'details';
  caption: {
    hr: string;
    en: string;
  };
  aspectRatio?: 'tall' | 'wide' | 'square';
}

export interface ReviewItem {
  id: string;
  author: string;
  initials: string;
  rating: number;
  date: {
    hr: string;
    en: string;
  };
  content: {
    hr: string;
    en: string;
  };
  source: 'Google Review' | 'Google Maps';
  isLocalGuide?: boolean;
}

export interface AppointmentFormState {
  fullName: string;
  contact: string; // phone or email
  serviceId: string;
  preferredDate: string;
  preferredTime: string;
  message: string;
}
