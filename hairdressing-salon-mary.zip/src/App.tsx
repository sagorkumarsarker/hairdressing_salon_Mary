/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Language } from './types';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { BrandStory } from './components/BrandStory';
import { Services } from './components/Services';
import { Experience } from './components/Experience';
import { Gallery } from './components/Gallery';
import { Testimonials } from './components/Testimonials';
import { LocationSection } from './components/LocationSection';
import { AppointmentCTA } from './components/AppointmentCTA';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { MobileStickyBar } from './components/MobileStickyBar';
import { BookingModal } from './components/BookingModal';

export default function App() {
  const [lang, setLang] = useState<Language>('hr');
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [selectedServiceId, setSelectedServiceId] = useState<string | undefined>(undefined);

  const toggleLanguage = () => {
    setLang((prev) => (prev === 'hr' ? 'en' : 'hr'));
  };

  const handleOpenBooking = (serviceId?: string) => {
    setSelectedServiceId(serviceId);
    setIsBookingOpen(true);
  };

  const handleCloseBooking = () => {
    setIsBookingOpen(false);
    setSelectedServiceId(undefined);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F7F4EF] text-[#1C1C1C] antialiased selection:bg-[#C7A46A]/20 selection:text-[#1C1C1C]">
      {/* Top Sticky Navigation */}
      <Navbar
        lang={lang}
        onToggleLang={toggleLanguage}
        onOpenBooking={handleOpenBooking}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* 1. Hero Section */}
        <Hero
          lang={lang}
          onOpenBooking={() => handleOpenBooking()}
        />

        {/* 2. Brand Story / Intro */}
        <BrandStory
          lang={lang}
        />

        {/* 3. Services Grid */}
        <Services
          lang={lang}
          onSelectService={(serviceId) => handleOpenBooking(serviceId)}
        />

        {/* 4. The Mary Experience */}
        <Experience
          lang={lang}
        />

        {/* 5. Gallery Showcase */}
        <Gallery
          lang={lang}
        />

        {/* 6. Client Reviews / Google Reviews */}
        <Testimonials
          lang={lang}
        />

        {/* 7. Location & Schedule Section */}
        <LocationSection
          lang={lang}
        />

        {/* 8. Appointment CTA Banner */}
        <AppointmentCTA
          lang={lang}
          onOpenBooking={() => handleOpenBooking()}
        />

        {/* 9. Contact & Request Form */}
        <ContactSection
          lang={lang}
          preselectedServiceId={selectedServiceId}
        />
      </main>

      {/* Footer */}
      <Footer
        lang={lang}
        onOpenBooking={() => handleOpenBooking()}
      />

      {/* Mobile-only Sticky Quick Action Bar */}
      <MobileStickyBar
        lang={lang}
        onOpenBooking={() => handleOpenBooking()}
      />

      {/* Reusable Booking Request Modal */}
      <BookingModal
        isOpen={isBookingOpen}
        onClose={handleCloseBooking}
        lang={lang}
        initialServiceId={selectedServiceId}
      />
    </div>
  );
}
