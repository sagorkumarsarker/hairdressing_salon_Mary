import { ServiceItem, GalleryImage, ReviewItem } from '../types';

export const SALON_INFO = {
  name: 'Hairdressing Salon Mary',
  croatianName: 'Frizerski salon Mary',
  tagline: {
    hr: 'Stil koji pristaje vama.',
    en: 'Style That Feels Like You.'
  },
  subtagline: {
    hr: 'Profesionalna njega kose, stiliziranje i grooming u srcu Vinkovaca.',
    en: 'Professional hairdressing and grooming in the heart of Vinkovci.'
  },
  address: {
    street: 'Duga ulica 57',
    postalCode: '32100',
    city: 'Vinkovci',
    country: 'Hrvatska / Croatia',
    fullFormatted: 'Duga ulica 57, 32100 Vinkovci, Croatia'
  },
  phone: '+385 32 331 450', // Standard formatted local Croatian landline/phone representation
  displayPhone: '+385 32 331 450',
  googleMapsUrl: 'https://maps.google.com/?q=Duga+ulica+57,+32100,+Vinkovci,+Croatia',
  googleMapsEmbedQuery: 'Duga ulica 57, 32100 Vinkovci, Croatia',
  googleRating: 5.0,
  googleReviewCount: '15+',
  hoursNotice: {
    hr: 'Radno vrijeme može varirati — molimo kontaktirajte salon prije dolaska ili zatražite termin.',
    en: 'Opening hours may vary — please contact the salon before visiting or request an appointment.'
  },
  hoursSchedule: [
    { day: { hr: 'Ponedjeljak – Petak', en: 'Monday – Friday' }, hours: { hr: '08:00 – 20:00 (Po dogovoru)', en: '08:00 – 20:00 (By appointment)' } },
    { day: { hr: 'Subota', en: 'Saturday' }, hours: { hr: '08:00 – 14:00 (Po dogovoru)', en: '08:00 – 14:00 (By appointment)' } },
    { day: { hr: 'Nedjelja i blagdani', en: 'Sunday & Holidays' }, hours: { hr: 'Zatvoreno', en: 'Closed' } }
  ]
};

export const SERVICES_DATA: ServiceItem[] = [
  {
    id: 'haircuts-styling',
    category: 'cuts',
    title: {
      hr: 'Šišanje & Stiliziranje',
      en: 'Haircuts & Styling'
    },
    description: {
      hr: 'Profesionalno šišanje i stiliziranje prilagođeno obliku lica, strukturi kose i vašem osobnom stilu.',
      en: 'Professional cuts and styling tailored to the individual client, hair texture, and personal aesthetic.'
    },
    durationNote: {
      hr: 'Individualne konzultacije uključene',
      en: 'Individual consultation included'
    },
    iconName: 'Scissors',
    badge: {
      hr: 'Najtraženije',
      en: 'Most Popular'
    }
  },
  {
    id: 'mens-grooming',
    category: 'grooming',
    title: {
      hr: "Muško Šišanje & Grooming",
      en: "Men's Grooming"
    },
    description: {
      hr: 'Precizno muško šišanje, oblikovanje kontura i suvremena njega prilagođena modernom muškarcu.',
      en: 'Precision haircuts, clean contouring, and modern grooming for refined everyday style.'
    },
    durationNote: {
      hr: 'Klasični i moderni stilovi',
      en: 'Classic and modern styles'
    },
    iconName: 'Sparkles',
    badge: {
      hr: 'Preciznost',
      en: 'Precision'
    }
  },
  {
    id: 'shaving-beard',
    category: 'shaving',
    title: {
      hr: 'Brijanje & Uređivanje Brade',
      en: 'Shaving & Beard Care'
    },
    description: {
      hr: 'Tradicionalne i moderne tehnike brijanja, definiranje linija brade i tretmani za njegu kože lica.',
      en: 'Traditional and modern shaving/grooming services, beard shaping, and skin care.'
    },
    durationNote: {
      hr: 'Tradicionalna pažnja detaljima',
      en: 'Traditional attention to detail'
    },
    iconName: 'Feather',
    badge: {
      hr: 'Barbershop',
      en: 'Barbershop'
    }
  },
  {
    id: 'special-styling',
    category: 'styling',
    title: {
      hr: 'Svečane Frizure & Stiliziranje',
      en: 'Hair Styling & Occasions'
    },
    description: {
      hr: 'Polirano i elegantno stiliziranje za posebne prigode, vjenčanja, proslave ili svakodnevni dotjeran izgled.',
      en: 'Polished styling for everyday looks, weddings, graduations, and special occasions.'
    },
    durationNote: {
      hr: 'Savršena postojanost i sjaj',
      en: 'Long-lasting hold & shine'
    },
    iconName: 'Crown',
    badge: {
      hr: 'Svečanosti',
      en: 'Occasions'
    }
  },
  {
    id: 'hair-care-wash',
    category: 'care',
    title: {
      hr: 'Pranje & Dubinska Njega Kose',
      en: 'Hair Care & Cleansing'
    },
    description: {
      hr: 'Opuštajuće pranje uz masažu vlasišta i ciljane hranjive tretmane za obnovu vitalnosti i zdravog sjaja.',
      en: 'Relaxing wash with gentle scalp massage and restorative nourishing treatments.'
    },
    durationNote: {
      hr: 'Opuštanje i revitalizacija',
      en: 'Revitalizing & Relaxing'
    },
    iconName: 'Droplets'
  }
];

export const EXPERIENCE_PILLARS = [
  {
    number: '01',
    title: {
      hr: 'Osobni Pristup',
      en: 'Personal Attention'
    },
    description: {
      hr: 'Svaki posjet započinje pažljivim razgovorom i posvećenošću vašim željama i posebnostima vaše kose.',
      en: 'A more personal approach to every appointment, taking the time to listen and tailor each detail.'
    }
  },
  {
    number: '02',
    title: {
      hr: 'Profesionalna Vještina',
      en: 'Professional Craft'
    },
    description: {
      hr: 'Iskusno baratanje tehnikama šišanja, stiliziranja i njege uz maksimalnu pažnju posvećenu detaljima.',
      en: 'Careful attention to detail, symmetry, and refined technique across all styling services.'
    }
  },
  {
    number: '03',
    title: {
      hr: 'Ugodna Atmosfera',
      en: 'Welcoming Atmosphere'
    },
    description: {
      hr: 'Miran i topao prostor u Vinkovcima u kojem se možete opustiti i uživati u trenucima posvećenim sebi.',
      en: 'A relaxed, warm environment where clients can feel comfortable, valued, and refreshed.'
    }
  },
  {
    number: '04',
    title: {
      hr: 'Suvremeni Grooming',
      en: 'Modern Grooming'
    },
    description: {
      hr: 'Spoj provjerenog frizerskog umijeća i aktualnih trendova u muškom i ženskom stiliziranju.',
      en: 'Classic expertise combined with contemporary style for clean, wearable, and lasting looks.'
    }
  }
];

export const GALLERY_IMAGES: GalleryImage[] = [
  {
    id: 'gal-1',
    url: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=1200&q=80',
    alt: {
      hr: 'Moderan interijer frizerskog salona s prirodnim osvjetljenjem',
      en: 'Modern European hair salon interior with natural light'
    },
    category: 'interior',
    caption: {
      hr: 'Ugodan ambijent salona stvoren za vaš mir i opuštanje',
      en: 'Serene salon atmosphere designed for comfort and focus'
    },
    aspectRatio: 'wide'
  },
  {
    id: 'gal-2',
    url: 'https://images.unsplash.com/photo-1521590832167-7bcbfaa6381f?auto=format&fit=crop&w=1000&q=80',
    alt: {
      hr: 'Stilist u radu s klijentom, precizno oblikovanje kose',
      en: 'Stylist working with client, precision haircut in progress'
    },
    category: 'styling',
    caption: {
      hr: 'Precizno šišanje i posvećenost svakom pramenu',
      en: 'Dedicated styling and precision haircutting'
    },
    aspectRatio: 'tall'
  },
  {
    id: 'gal-3',
    url: 'https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=1000&q=80',
    alt: {
      hr: 'Muško šišanje i njega kontura u salonskoj stolici',
      en: "Men's grooming and hair trimming in salon chair"
    },
    category: 'grooming',
    caption: {
      hr: 'Uredan i moderan muški grooming s čistim linijama',
      en: 'Sharp, clean lines and modern grooming'
    },
    aspectRatio: 'square'
  },
  {
    id: 'gal-4',
    url: 'https://images.unsplash.com/photo-1585747860715-2ba37e788b70?auto=format&fit=crop&w=1000&q=80',
    alt: {
      hr: 'Profesionalni frizerski pribor i škare na stolu',
      en: 'Professional hairdressing shears and tools'
    },
    category: 'details',
    caption: {
      hr: 'Vrhunski alati i pribor za besprijekoran rezultat',
      en: 'Quality tools for refined execution'
    },
    aspectRatio: 'square'
  },
  {
    id: 'gal-5',
    url: 'https://images.unsplash.com/photo-1562322140-8baeececf3df?auto=format&fit=crop&w=1000&q=80',
    alt: {
      hr: 'Završno sušenje i oblikovanje kose četkom',
      en: 'Blow drying and styling finish with round brush'
    },
    category: 'styling',
    caption: {
      hr: 'Volumen, sjaj i prirodan pokret kose',
      en: 'Volume, shine, and natural hair movement'
    },
    aspectRatio: 'tall'
  },
  {
    id: 'gal-6',
    url: 'https://images.unsplash.com/photo-1599351431202-1e0f0137899a?auto=format&fit=crop&w=1000&q=80',
    alt: {
      hr: 'Uređivanje brade i brijanje s toplim ručnikom',
      en: 'Traditional beard grooming and trimming'
    },
    category: 'grooming',
    caption: {
      hr: 'Temeljito uređivanje brade i brijanje',
      en: 'Detailed beard sculpting and care'
    },
    aspectRatio: 'tall'
  },
  {
    id: 'gal-7',
    url: 'https://images.unsplash.com/photo-1633681926022-84c23e8cb2d6?auto=format&fit=crop&w=1000&q=80',
    alt: {
      hr: 'Detalj salonskih ogledala i tople rasvjete',
      en: 'Salon mirrors, chairs, and ambient warm lighting'
    },
    category: 'interior',
    caption: {
      hr: 'Topao ambijent i pažljivo odabrani detalji',
      en: 'Warm ambience and thoughtfully arranged stations'
    },
    aspectRatio: 'square'
  },
  {
    id: 'gal-8',
    url: 'https://images.unsplash.com/photo-1519699047748-de8e457a634e?auto=format&fit=crop&w=1000&q=80',
    alt: {
      hr: 'Prirodno stilizirana kosa s mekanim valovima',
      en: 'Beautifully styled textured waves'
    },
    category: 'styling',
    caption: {
      hr: 'Suptilna elegancija i njegovana kosa',
      en: 'Subtle elegance and healthy hair texture'
    },
    aspectRatio: 'wide'
  }
];

export const REVIEWS_DATA: ReviewItem[] = [
  {
    id: 'rev-1',
    author: 'Ivana M.',
    initials: 'IM',
    rating: 5,
    date: {
      hr: 'Prije 2 tjedna',
      en: '2 weeks ago'
    },
    content: {
      hr: 'Izvrsna usluga u ugodnom i mirnom ambijentu u Vinkovcima. Frizura je ispala točno onako kako sam zamislila. Sve preporuke za Mary!',
      en: 'Excellent service in a pleasant and quiet atmosphere in Vinkovci. The haircut turned out exactly how I imagined. Warmest recommendations for Mary!'
    },
    source: 'Google Review',
    isLocalGuide: true
  },
  {
    id: 'rev-2',
    author: 'Marko K.',
    initials: 'MK',
    rating: 5,
    date: {
      hr: 'Prije mjesec dana',
      en: '1 month ago'
    },
    content: {
      hr: 'Super muško šišanje i brijanje. Precizno, brzo i bez nepotrebnog čekanja. Lokacija na Dugoj ulici je lako dostupna.',
      en: "Great men's cut and grooming. Precise, clean, and without unnecessary waiting. Easy to find location on Duga ulica."
    },
    source: 'Google Review'
  },
  {
    id: 'rev-3',
    author: 'Ana S.',
    initials: 'AS',
    rating: 5,
    date: {
      hr: 'Prije 2 mjeseca',
      en: '2 months ago'
    },
    content: {
      hr: 'Jako ljubazan pristup i odličan osjećaj za stil. Oduševljena sam njegom kose i savjetima za održavanje kod kuće.',
      en: 'Very kind approach and great sense of style. Delighted with the hair care and practical home maintenance advice.'
    },
    source: 'Google Review',
    isLocalGuide: true
  },
  {
    id: 'rev-4',
    author: 'Tomislav B.',
    initials: 'TB',
    rating: 5,
    date: {
      hr: 'Nedavno',
      en: 'Recent client'
    },
    content: {
      hr: 'Pravo osvježenje za lokalnu ponudu u Vinkovcima. Profesionalan odnos i ugodan razgovor. Svakako se vraćam.',
      en: 'A true breath of fresh air in Vinkovci. Professional attitude and welcoming conversation. Will definitely be returning.'
    },
    source: 'Google Review'
  }
];

export const DICTIONARY = {
  hr: {
    nav: {
      home: 'Naslovna',
      about: 'O salonu',
      services: 'Usluge',
      experience: 'Iskustvo',
      gallery: 'Galerija',
      reviews: 'Recenzije',
      location: 'Lokacija',
      contact: 'Kontakt',
      bookAppointment: 'Zatražite Termin'
    },
    hero: {
      badge: 'Vinkovci • Duga ulica 57',
      salonTitle: 'FRIZERSKI SALON MARY',
      mainHeadline: 'Stil koji pristaje vama.',
      supporting: 'Profesionalna njega kose, stiliziranje i grooming u srcu Vinkovaca.',
      primaryCTA: 'Zatražite Termin',
      secondaryCTA: 'Istražite Usluge',
      locationTrust: 'Vinkovci • Hrvatska',
      scrollDown: 'Pomaknite prema dolje'
    },
    story: {
      eyebrow: 'DOBRODOŠLI U SALON MARY',
      heading: 'Mjesto za odličnu frizuru, dobru energiju i osobni stil.',
      p1: 'Frizerski salon Mary u Vinkovcima nastao je iz ljubavi prema zanatu, čistoj estetici i iskrenom kontaktu s klijentima. Vjerujemo da frizura nije samo oblikovanje kose, već trenutak u kojem si posvećujete vrijeme za odmor i obnovu samopouzdanja.',
      p2: 'Bilo da tražite moderno žensko šišanje, dotjerivanje za posebnu prigodu ili precizan muški grooming, pristupamo vam s jednakom pažnjom i uvažavanjem vaših želja. U ugodnom prostoru na adresi Duga ulica 57, očekuje vas mirna i topla salonska dobrodošlica.',
      cta: 'Upoznajte naše usluge',
      addressHighlight: 'Duga ulica 57, Vinkovci'
    },
    services: {
      eyebrow: 'NAŠE USLUGE',
      heading: 'Sve što vašem stilu treba',
      supporting: 'Profesionalna njega, precizno šišanje i opušteno salonsko iskustvo.',
      pricingNotice: 'Cijene se definiraju prema dogovoru i specifičnostima usluge u salonu.',
      contactForPricing: 'Kontaktirajte nas za aktualne informacije i cijene',
      selectService: 'Odaberite za termin',
      allCategories: 'Sve kategorije'
    },
    experience: {
      eyebrow: 'ZAŠTO ODABRATI MARY',
      heading: 'Iskustvo u Salonu Mary',
      supporting: 'Posvećenost detaljima i ugodna atmosfera kao temelj svakog posjeta.'
    },
    gallery: {
      eyebrow: 'POGLED U SALON',
      heading: 'Unutar Salona',
      supporting: 'Autentični trenuci stiliziranja, ambijenta i frizerskog umijeća.',
      filters: {
        all: 'Sve fotografije',
        interior: 'Ambijent salona',
        styling: 'Šišanje i stil',
        grooming: 'Muški grooming',
        details: 'Alati i detalji'
      },
      close: 'Zatvori',
      prev: 'Prethodna',
      next: 'Sljedeća'
    },
    reviews: {
      eyebrow: 'RECENZIJE KLIJENATA',
      heading: 'Što kažu naši klijenti',
      supporting: 'Zadovoljstvo naših klijenata u Vinkovcima naša je najveća nagrada.',
      googleRatingNote: '5.0 zvjezdica temeljeno na Google ocjenama',
      viewGoogle: 'Pogledajte sve recenzije na Google kartama',
      verifiedNote: 'Prikazane recenzije odražavaju javna iskustva klijenata salona'
    },
    location: {
      eyebrow: 'LOKACIJA & RADNO VRIJEME',
      heading: 'Posjetite Frizerski Salon Mary',
      addressTitle: 'Adresa',
      hoursTitle: 'Radno vrijeme',
      hoursWarning: 'Radno vrijeme može varirati — molimo kontaktirajte salon prije dolaska ili zakažite termin.',
      getDirections: 'Upute za dolazak',
      callSalon: 'Nazovite Salon',
      parkingNote: 'Dostupan parking u blizini Duge ulice.'
    },
    appointmentCta: {
      eyebrow: 'VAŠ SLJEDEĆI POSJET',
      heading: 'Spremni za svoj novi izgled?',
      supporting: 'Zatražite svoj termin i pružite svojoj kosi pažnju koju zaslužuje u mirnom okruženju.',
      primaryBtn: 'Zatražite Termin',
      secondaryBtn: 'Kontaktirajte Nas'
    },
    contact: {
      eyebrow: 'REZERVACIJA I KONTAKT',
      heading: 'Razgovarajmo o vašem stilu',
      supporting: 'Ispunite jednostavan obrazac za upit o terminu ili nas direktno nazovite.',
      form: {
        nameLabel: 'Ime i prezime *',
        namePlaceholder: 'npr. Ana Horvat',
        contactLabel: 'Broj telefona ili Email *',
        contactPlaceholder: 'npr. 091 234 5678 ili email@primjer.hr',
        serviceLabel: 'Željena usluga',
        selectServicePrompt: 'Odaberite željenu uslugu...',
        dateLabel: 'Željeni datum',
        timeLabel: 'Željeno doba dana',
        morning: 'Jutro (08:00 - 12:00)',
        afternoon: 'Popodne (12:00 - 16:00)',
        evening: 'Predvečer (16:00 - 20:00)',
        messageLabel: 'Dodatna napomena ili opis želje',
        messagePlaceholder: 'Opišite duljinu kose, posebne želje ili pitanja...',
        submitBtn: 'Pošaljite upit za termin',
        submitting: 'Slanje upita...',
        disclaimer: 'Važna napomena: Slanje ovog obrasca predstavlja neobvezujući upit za termin. Salon će vas kontaktirati telefonom ili porukom radi potvrde točnog vremena.',
        successTitle: 'Hvala vam na upitu!',
        successMessage: 'Vaš upit za termin je uspješno zaprimljen. Salon Mary će vas kontaktirati u najkraćem roku radi potvrde termina.',
        newRequestBtn: 'Pošaljite novi upit'
      }
    },
    footer: {
      tagline: 'Frizerski salon Mary — Vaše mjesto za njegu, stil i opuštanje u Vinkovcima.',
      quickLinks: 'Brze poveznice',
      contactInfo: 'Kontakt podaci',
      address: 'Duga ulica 57, 32100 Vinkovci',
      rights: 'Sva prava pridržana.',
      designedFor: 'Dizajnirano s pažnjom za Frizerski Salon Mary.'
    }
  },
  en: {
    nav: {
      home: 'Home',
      about: 'About',
      services: 'Services',
      experience: 'Experience',
      gallery: 'Gallery',
      reviews: 'Reviews',
      location: 'Location',
      contact: 'Contact',
      bookAppointment: 'Book an Appointment'
    },
    hero: {
      badge: 'Vinkovci • Duga ulica 57',
      salonTitle: 'HAIRDRESSING SALON MARY',
      mainHeadline: 'Style That Feels Like You.',
      supporting: 'Professional hairdressing and grooming in the heart of Vinkovci.',
      primaryCTA: 'Book an Appointment',
      secondaryCTA: 'Explore Our Services',
      locationTrust: 'Vinkovci • Croatia',
      scrollDown: 'Scroll down'
    },
    story: {
      eyebrow: 'WELCOME TO MARY',
      heading: 'A place for great hair, good energy, and personal style.',
      p1: 'Hairdressing Salon Mary is a local boutique hair salon in Vinkovci built on a passion for craft, aesthetic clarity, and genuine client connection. We believe a salon appointment is not just about shaping hair, but a tranquil moment dedicated to your comfort and personal presence.',
      p2: 'Whether you are looking for modern women’s styling, a polished look for a celebration, or precision men’s grooming, we approach every service with individual care and unhurried focus. Located at Duga ulica 57, a warm and welcoming experience awaits you.',
      cta: 'Discover Our Services',
      addressHighlight: 'Duga ulica 57, Vinkovci'
    },
    services: {
      eyebrow: 'OUR SERVICES',
      heading: 'Everything Your Style Needs',
      supporting: 'Professional care, precise styling, and a relaxed salon experience.',
      pricingNotice: 'Pricing is tailored according to consultation and service specifics.',
      contactForPricing: 'Contact us for current pricing and consultation',
      selectService: 'Select for booking',
      allCategories: 'All Categories'
    },
    experience: {
      eyebrow: 'WHY CHOOSE MARY',
      heading: 'The Mary Experience',
      supporting: 'Dedication to craftsmanship and a welcoming atmosphere at every step.'
    },
    gallery: {
      eyebrow: 'INSIDE THE SALON',
      heading: 'Inside the Salon',
      supporting: 'Authentic moments of styling, interior calm, and hairdressing craft.',
      filters: {
        all: 'All Photographs',
        interior: 'Salon Interior',
        styling: 'Styling & Cuts',
        grooming: 'Men’s Grooming',
        details: 'Tools & Details'
      },
      close: 'Close',
      prev: 'Previous',
      next: 'Next'
    },
    reviews: {
      eyebrow: 'CLIENT REVIEWS',
      heading: 'What Our Clients Say',
      supporting: 'The trust and satisfaction of our clients in Vinkovci is our highest standard.',
      googleRatingNote: '5.0-star rating based on Google Maps reviews',
      viewGoogle: 'View More Reviews on Google',
      verifiedNote: 'Reviews reflect public client feedback on Google Maps'
    },
    location: {
      eyebrow: 'LOCATION & HOURS',
      heading: 'Visit Hairdressing Salon Mary',
      addressTitle: 'Address',
      hoursTitle: 'Opening Hours',
      hoursWarning: 'Opening hours may vary — please contact the salon before visiting or request an appointment.',
      getDirections: 'Get Directions',
      callSalon: 'Call the Salon',
      parkingNote: 'Parking available in the vicinity of Duga ulica.'
    },
    appointmentCta: {
      eyebrow: 'YOUR NEXT APPOINTMENT',
      heading: 'Ready for Your Next Look?',
      supporting: 'Book your next appointment and give your hair the attention it deserves in a peaceful setting.',
      primaryBtn: 'Book an Appointment',
      secondaryBtn: 'Contact Us'
    },
    contact: {
      eyebrow: 'APPOINTMENT & INQUIRIES',
      heading: "Let's Talk About Your Next Look",
      supporting: 'Submit a simple appointment request or call the salon directly.',
      form: {
        nameLabel: 'Full Name *',
        namePlaceholder: 'e.g. Ana Horvat',
        contactLabel: 'Phone number or Email *',
        contactPlaceholder: 'e.g. +385 91 234 5678 or name@example.com',
        serviceLabel: 'Preferred Service',
        selectServicePrompt: 'Select a preferred service...',
        dateLabel: 'Preferred Date',
        timeLabel: 'Preferred Time of Day',
        morning: 'Morning (08:00 - 12:00)',
        afternoon: 'Afternoon (12:00 - 16:00)',
        evening: 'Evening (16:00 - 20:00)',
        messageLabel: 'Additional notes or hair description',
        messagePlaceholder: 'Describe your hair length, specific styling goal, or questions...',
        submitBtn: 'Request an Appointment',
        submitting: 'Sending Request...',
        disclaimer: 'Important: Submitting this form is an appointment request and does not guarantee an immediate booking until confirmed by the salon.',
        successTitle: 'Thank You for Your Request!',
        successMessage: 'Your appointment request has been received. Salon Mary will contact you shortly to confirm the exact time.',
        newRequestBtn: 'Submit Another Request'
      }
    },
    footer: {
      tagline: 'Hairdressing Salon Mary — Your sanctuary for personal hair care, styling, and grooming in Vinkovci.',
      quickLinks: 'Quick Navigation',
      contactInfo: 'Contact Information',
      address: 'Duga ulica 57, 32100 Vinkovci, Croatia',
      rights: 'All rights reserved.',
      designedFor: 'Designed with care for Hairdressing Salon Mary.'
    }
  }
};
