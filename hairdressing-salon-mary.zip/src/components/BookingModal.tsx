import React, { useState, useEffect } from 'react';
import { X, Calendar, CheckCircle2, Phone, AlertCircle, Send } from 'lucide-react';
import { Language, AppointmentFormState } from '../types';
import { DICTIONARY, SALON_INFO, SERVICES_DATA } from '../data/salonData';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  initialServiceId?: string;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  isOpen,
  onClose,
  lang,
  initialServiceId
}) => {
  const t = DICTIONARY[lang];

  const [formState, setFormState] = useState<AppointmentFormState>({
    fullName: '',
    contact: '',
    serviceId: initialServiceId || '',
    preferredDate: '',
    preferredTime: 'morning',
    message: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    if (initialServiceId) {
      setFormState((prev) => ({ ...prev, serviceId: initialServiceId }));
    }
  }, [initialServiceId]);

  // Handle escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formState.fullName.trim() || !formState.contact.trim()) {
      setErrorMsg(lang === 'hr' ? 'Molimo unesite vaše ime i kontakt.' : 'Please enter your full name and contact information.');
      return;
    }

    setErrorMsg(null);
    setIsSubmitting(true);

    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 500);
  };

  const handleCloseAndReset = () => {
    setIsSubmitted(false);
    onClose();
  };

  return (
    <div
      id="booking-modal-overlay"
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto"
      onClick={handleCloseAndReset}
    >
      <div
        id="booking-modal-content"
        className="relative w-full max-w-lg bg-[#F7F4EF] shadow-2xl border border-[#1C1C1C]/15 p-6 sm:p-8 my-8 text-left"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={handleCloseAndReset}
          className="absolute top-5 right-5 p-2 text-[#7A746E] hover:text-[#1C1C1C] transition-colors"
          aria-label="Close booking modal"
        >
          <X className="w-5 h-5" />
        </button>

        {isSubmitted ? (
          <div className="py-6 text-center space-y-4">
            <div className="w-14 h-14 bg-white text-[#C7A46A] flex items-center justify-center mx-auto border border-[#1C1C1C]/10">
              <CheckCircle2 className="w-7 h-7" />
            </div>
            <h3 className="text-2xl font-serif text-[#1C1C1C]">
              {t.contact.form.successTitle}
            </h3>
            <p className="text-sm text-[#55524E] leading-relaxed">
              {t.contact.form.successMessage}
            </p>

            <div className="bg-white p-4 text-xs space-y-1 text-left border border-[#1C1C1C]/10 text-[#55524E]">
              <p><strong className="text-[#1C1C1C]">{lang === 'hr' ? 'Ime:' : 'Name:'}</strong> {formState.fullName}</p>
              <p><strong className="text-[#1C1C1C]">{lang === 'hr' ? 'Kontakt:' : 'Contact:'}</strong> {formState.contact}</p>
              <p><strong className="text-[#1C1C1C]">{lang === 'hr' ? 'Lokacija:' : 'Location:'}</strong> {SALON_INFO.address.fullFormatted}</p>
            </div>

            <div className="pt-4 flex flex-col sm:flex-row gap-3 justify-center">
              <button
                onClick={handleCloseAndReset}
                className="px-5 py-3 border border-[#1C1C1C] text-[10px] uppercase tracking-[0.2em] font-bold text-[#1C1C1C] hover:bg-[#1C1C1C] hover:text-white transition-colors"
              >
                {lang === 'hr' ? 'Zatvori' : 'Close Window'}
              </button>
              <a
                href={`tel:${SALON_INFO.phone.replace(/\s+/g, '')}`}
                className="px-5 py-3 bg-[#C7A46A] text-white text-[10px] uppercase tracking-[0.2em] font-bold hover:bg-[#B89355] transition-colors flex items-center justify-center gap-2"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>{SALON_INFO.displayPhone}</span>
              </a>
            </div>
          </div>
        ) : (
          <div>
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-1">
                <span className="w-5 h-[1.5px] bg-[#C7A46A]" />
                <span className="text-[10px] uppercase tracking-[0.25em] font-bold text-[#C7A46A]">
                  Hairdressing Salon Mary
                </span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-serif text-[#1C1C1C] font-normal">
                {t.nav.bookAppointment}
              </h3>
              <p className="text-xs text-[#6B6864] mt-1">
                {lang === 'hr' ? 'Duga ulica 57, Vinkovci' : 'Duga ulica 57, Vinkovci, Croatia'}
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {errorMsg && (
                <div className="p-2.5 bg-red-50 border border-red-200 text-red-700 text-xs">
                  {errorMsg}
                </div>
              )}

              <div>
                <label className="block text-[10px] uppercase tracking-[0.2em] font-bold text-[#1C1C1C] mb-1.5">
                  {t.contact.form.nameLabel}
                </label>
                <input
                  type="text"
                  required
                  value={formState.fullName}
                  onChange={(e) => setFormState({ ...formState, fullName: e.target.value })}
                  placeholder={t.contact.form.namePlaceholder}
                  className="w-full px-3.5 py-2.5 border border-[#1C1C1C]/15 bg-white text-sm text-[#1C1C1C] focus:outline-none focus:border-[#1C1C1C]"
                />
              </div>

              <div>
                <label className="block text-[10px] uppercase tracking-[0.2em] font-bold text-[#1C1C1C] mb-1.5">
                  {t.contact.form.contactLabel}
                </label>
                <input
                  type="text"
                  required
                  value={formState.contact}
                  onChange={(e) => setFormState({ ...formState, contact: e.target.value })}
                  placeholder={t.contact.form.contactPlaceholder}
                  className="w-full px-3.5 py-2.5 border border-[#1C1C1C]/15 bg-white text-sm text-[#1C1C1C] focus:outline-none focus:border-[#1C1C1C]"
                />
              </div>

              <div>
                <label className="block text-[10px] uppercase tracking-[0.2em] font-bold text-[#1C1C1C] mb-1.5">
                  {t.contact.form.serviceLabel}
                </label>
                <select
                  value={formState.serviceId}
                  onChange={(e) => setFormState({ ...formState, serviceId: e.target.value })}
                  className="w-full px-3.5 py-2.5 border border-[#1C1C1C]/15 bg-white text-sm text-[#1C1C1C] focus:outline-none focus:border-[#1C1C1C]"
                >
                  <option value="">{t.contact.form.selectServicePrompt}</option>
                  {SERVICES_DATA.map((service) => (
                    <option key={service.id} value={service.id}>
                      {service.title[lang]}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] uppercase tracking-[0.2em] font-bold text-[#1C1C1C] mb-1.5">
                    {t.contact.form.dateLabel}
                  </label>
                  <input
                    type="date"
                    value={formState.preferredDate}
                    onChange={(e) => setFormState({ ...formState, preferredDate: e.target.value })}
                    className="w-full px-3 py-2 border border-[#1C1C1C]/15 bg-white text-xs text-[#1C1C1C] focus:outline-none focus:border-[#1C1C1C]"
                  />
                </div>
                <div>
                  <label className="block text-[10px] uppercase tracking-[0.2em] font-bold text-[#1C1C1C] mb-1.5">
                    {t.contact.form.timeLabel}
                  </label>
                  <select
                    value={formState.preferredTime}
                    onChange={(e) => setFormState({ ...formState, preferredTime: e.target.value })}
                    className="w-full px-3 py-2 border border-[#1C1C1C]/15 bg-white text-xs text-[#1C1C1C] focus:outline-none focus:border-[#1C1C1C]"
                  >
                    <option value="morning">{t.contact.form.morning}</option>
                    <option value="afternoon">{t.contact.form.afternoon}</option>
                    <option value="evening">{t.contact.form.evening}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase tracking-[0.2em] font-bold text-[#1C1C1C] mb-1.5">
                  {t.contact.form.messageLabel}
                </label>
                <textarea
                  rows={2}
                  value={formState.message}
                  onChange={(e) => setFormState({ ...formState, message: e.target.value })}
                  placeholder={t.contact.form.messagePlaceholder}
                  className="w-full px-3.5 py-2 border border-[#1C1C1C]/15 bg-white text-xs text-[#1C1C1C] placeholder:text-[#9E978E] focus:outline-none focus:border-[#1C1C1C]"
                />
              </div>

              {/* Disclaimer */}
              <div className="p-3 bg-white border border-[#1C1C1C]/10 flex items-start gap-2 text-xs text-[#7A746E]">
                <AlertCircle className="w-4 h-4 text-[#C7A46A] shrink-0 mt-0.5" />
                <span>{t.contact.form.disclaimer}</span>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full inline-flex items-center justify-center gap-2 bg-[#1C1C1C] hover:bg-[#C7A46A] text-white py-3.5 px-5 text-[10px] uppercase tracking-[0.2em] font-bold transition-all shadow-xs active:scale-[0.99] disabled:opacity-75 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{isSubmitting ? t.contact.form.submitting : t.contact.form.submitBtn}</span>
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
