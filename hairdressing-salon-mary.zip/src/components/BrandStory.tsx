import React from 'react';
import { ArrowRight, Check, MapPin, Sparkles } from 'lucide-react';
import { Language } from '../types';
import { DICTIONARY, SALON_INFO } from '../data/salonData';

interface BrandStoryProps {
  lang: Language;
}

export const BrandStory: React.FC<BrandStoryProps> = ({ lang }) => {
  const t = DICTIONARY[lang];

  return (
    <section id="about" className="py-20 lg:py-28 bg-[#F7F4EF] relative border-b border-[#1C1C1C]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Column: Editorial Photo Showcase */}
          <div className="lg:col-span-6 relative">
            <div className="relative mx-auto max-w-lg lg:max-w-none">
              {/* Main Photo Frame */}
              <div className="relative rounded-none overflow-hidden aspect-[4/5] bg-[#E8DED2] border border-[#1C1C1C]/15">
                <img
                  src="https://images.unsplash.com/photo-1521590832167-7bcbfaa6381f?auto=format&fit=crop&w=1200&q=80"
                  alt="Stylist working with client inside modern salon"
                  className="w-full h-full object-cover object-center filter contrast-[102%]"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-60" />
                
                {/* Floating Experience Badge */}
                <div className="absolute bottom-6 left-6 right-6 p-4 sm:p-5 bg-white/95 backdrop-blur-md border border-[#1C1C1C]/10 shadow-lg flex items-center gap-4">
                  <div className="w-10 h-10 bg-[#1C1C1C] flex items-center justify-center text-[#C7A46A] shrink-0">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-wider font-bold text-[#1C1C1C]">
                      {lang === 'hr' ? 'Individualan rad s klijentima' : 'Dedicated 1:1 Salon Experience'}
                    </p>
                    <p className="text-[11px] text-[#7A746E] flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3 h-3 text-[#C7A46A]" />
                      <span>{SALON_INFO.address.street}, Vinkovci</span>
                    </p>
                  </div>
                </div>
              </div>

              {/* Decorative Accent Background Box */}
              <div className="absolute -bottom-4 -left-4 w-full h-full border border-[#1C1C1C]/15 -z-10 hidden sm:block pointer-events-none" />
            </div>
          </div>

          {/* Right Column: Editorial Narrative */}
          <div className="lg:col-span-6 flex flex-col justify-center">
            {/* Eyebrow */}
            <div className="flex items-center gap-2 mb-3">
              <span className="w-6 h-[1.5px] bg-[#C7A46A]" />
              <span className="text-[10px] uppercase tracking-[0.3em] font-bold text-[#C7A46A]">
                {t.story.eyebrow}
              </span>
            </div>

            {/* Heading */}
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-normal text-[#1C1C1C] leading-[1.12] mb-6 text-balance">
              {t.story.heading}
            </h2>

            {/* Body Paragraphs */}
            <div className="space-y-4 text-sm sm:text-base text-[#1C1C1C]/70 leading-relaxed font-light mb-8">
              <p>{t.story.p1}</p>
              <p>{t.story.p2}</p>
            </div>

            {/* Key Value Points */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 mb-8 pb-8 border-b border-[#1C1C1C]/10">
              <div className="flex items-start gap-2.5">
                <span className="w-4 h-4 mt-0.5 flex items-center justify-center text-[#C7A46A] border border-[#C7A46A] text-[10px] font-bold shrink-0">✓</span>
                <span className="text-xs sm:text-sm font-medium text-[#1C1C1C]">
                  {lang === 'hr' ? 'Konzultacija prije šišanja' : 'Consultation before styling'}
                </span>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="w-4 h-4 mt-0.5 flex items-center justify-center text-[#C7A46A] border border-[#C7A46A] text-[10px] font-bold shrink-0">✓</span>
                <span className="text-xs sm:text-sm font-medium text-[#1C1C1C]">
                  {lang === 'hr' ? 'Precizno muško i žensko šišanje' : 'Precision cuts & grooming'}
                </span>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="w-4 h-4 mt-0.5 flex items-center justify-center text-[#C7A46A] border border-[#C7A46A] text-[10px] font-bold shrink-0">✓</span>
                <span className="text-xs sm:text-sm font-medium text-[#1C1C1C]">
                  {lang === 'hr' ? 'Kvalitetni profesionalni preparati' : 'Carefully selected hair products'}
                </span>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="w-4 h-4 mt-0.5 flex items-center justify-center text-[#C7A46A] border border-[#C7A46A] text-[10px] font-bold shrink-0">✓</span>
                <span className="text-xs sm:text-sm font-medium text-[#1C1C1C]">
                  {lang === 'hr' ? 'Opuštena i ugodna atmosfera' : 'Calm, welcoming atmosphere'}
                </span>
              </div>
            </div>

            {/* CTA Link */}
            <div className="flex items-center">
              <a
                href="#services"
                id="story-services-link"
                className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.2em] font-bold text-[#1C1C1C] hover:text-[#C7A46A] transition-colors group"
              >
                <span>{t.story.cta}</span>
                <ArrowRight className="w-4 h-4 text-[#C7A46A] transform group-hover:translate-x-1.5 transition-transform" />
              </a>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
