import React from 'react';
import { Star, ExternalLink, MessageSquareQuote, ShieldCheck } from 'lucide-react';
import { Language } from '../types';
import { DICTIONARY, REVIEWS_DATA, SALON_INFO } from '../data/salonData';

interface TestimonialsProps {
  lang: Language;
}

export const Testimonials: React.FC<TestimonialsProps> = ({ lang }) => {
  const t = DICTIONARY[lang];

  return (
    <section id="reviews" className="py-20 lg:py-28 bg-[#F7F4EF] relative border-b border-[#1C1C1C]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 mb-3">
            <span className="w-5 h-[1.5px] bg-[#C7A46A]" />
            <span className="text-[10px] uppercase tracking-[0.3em] font-bold text-[#C7A46A]">
              {t.reviews.eyebrow}
            </span>
            <span className="w-5 h-[1.5px] bg-[#C7A46A]" />
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-normal text-[#1C1C1C] mb-4">
            {t.reviews.heading}
          </h2>
          <p className="text-sm sm:text-base text-[#1C1C1C]/65 font-light max-w-2xl mx-auto">
            {t.reviews.supporting}
          </p>

          {/* Rating Summary Card */}
          <div className="mt-8 inline-flex items-center gap-4 py-3.5 px-6 bg-white border border-[#1C1C1C]/10">
            <div className="flex items-center text-[#C7A46A]">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-current" />
              ))}
            </div>
            <span className="text-xs font-bold text-[#1C1C1C] tracking-wide font-serif">
              {SALON_INFO.googleRating.toFixed(1)} / 5.0
            </span>
            <span className="text-xs text-[#7A746E] border-l border-[#1C1C1C]/10 pl-4">
              Google Maps Vinkovci
            </span>
          </div>
        </div>

        {/* Testimonials Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {REVIEWS_DATA.map((review) => (
            <div
              key={review.id}
              className="bg-white p-7 border border-[#1C1C1C]/10 hover:border-[#1C1C1C] transition-all flex flex-col justify-between"
            >
              <div>
                {/* Header with Initials, Author, and Rating */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 bg-[#F7F4EF] text-[#C7A46A] font-serif font-semibold flex items-center justify-center text-xs border border-[#C7A46A]/20">
                      {review.initials}
                    </div>
                    <div>
                      <p className="text-xs font-bold text-[#1C1C1C] uppercase tracking-wider">
                        {review.author}
                      </p>
                      <p className="text-[10px] text-[#7A746E]">
                        {review.date[lang]}
                      </p>
                    </div>
                  </div>

                  {review.isLocalGuide && (
                    <span className="text-[8px] uppercase tracking-[0.2em] font-bold px-2 py-0.5 bg-[#F7F4EF] text-[#1C1C1C] border border-[#1C1C1C]/10">
                      Local Guide
                    </span>
                  )}
                </div>

                {/* Stars */}
                <div className="flex items-center text-[#C7A46A] mb-4 gap-0.5">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-current" />
                  ))}
                </div>

                {/* Content */}
                <p className="text-xs sm:text-sm text-[#1C1C1C]/75 font-light leading-relaxed mb-4 italic">
                  "{review.content[lang]}"
                </p>
              </div>

              {/* Source Tag */}
              <div className="pt-3 border-t border-[#1C1C1C]/10 flex items-center justify-between text-[11px] text-[#7A746E]">
                <span className="flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#C7A46A]" />
                  <span>Google Review</span>
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* View on Google Maps Button & Verification Note */}
        <div className="flex flex-col items-center justify-center text-center space-y-3">
          <a
            href={SALON_INFO.googleMapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            id="google-reviews-external-btn"
            className="inline-flex items-center gap-2 px-7 py-3.5 bg-[#1C1C1C] text-white text-[10px] uppercase tracking-[0.2em] font-bold hover:bg-[#C7A46A] transition-all shadow-xs active:scale-[0.98]"
          >
            <span>{t.reviews.viewGoogle}</span>
            <ExternalLink className="w-3.5 h-3.5 text-[#C7A46A]" />
          </a>
          <p className="text-[11px] text-[#7A746E]">
            {t.reviews.verifiedNote}
          </p>
        </div>

      </div>
    </section>
  );
};
