import React from 'react';
import { Phone, Calendar } from 'lucide-react';
import { Language } from '../types';
import { DICTIONARY, SALON_INFO } from '../data/salonData';

interface MobileStickyBarProps {
  lang: Language;
  onOpenBooking: () => void;
}

export const MobileStickyBar: React.FC<MobileStickyBarProps> = ({ lang, onOpenBooking }) => {
  const t = DICTIONARY[lang];

  return (
    <div
      id="mobile-sticky-cta-bar"
      className="fixed bottom-0 left-0 right-0 z-30 sm:hidden bg-[#F7F4EF]/95 backdrop-blur-md border-t border-[#1C1C1C]/10 p-3 shadow-lg flex items-center gap-3"
    >
      {/* Call Button */}
      <a
        href={`tel:${SALON_INFO.phone.replace(/\s+/g, '')}`}
        className="flex-1 inline-flex items-center justify-center gap-2 py-3 px-3 bg-white border border-[#1C1C1C]/15 text-[#1C1C1C] text-[10px] uppercase tracking-[0.16em] font-bold active:bg-[#EFEAE1]"
        aria-label="Call salon"
      >
        <Phone className="w-3.5 h-3.5 text-[#C7A46A]" />
        <span>{lang === 'hr' ? 'Poziv' : 'Call'}</span>
      </a>

      {/* Book Button */}
      <button
        onClick={onOpenBooking}
        className="flex-1 inline-flex items-center justify-center gap-2 py-3 px-3 bg-[#1C1C1C] active:bg-[#C7A46A] text-white text-[10px] uppercase tracking-[0.16em] font-bold shadow-xs"
        aria-label="Book appointment"
      >
        <Calendar className="w-3.5 h-3.5 text-[#C7A46A]" />
        <span>{lang === 'hr' ? 'Termin' : 'Book'}</span>
      </button>
    </div>
  );
};
