import React from 'react';
import { Calendar, Phone, ArrowDown } from 'lucide-react';
import { Language } from '../types';
import { DICTIONARY, SALON_INFO } from '../data/salonData';

interface AppointmentCTAProps {
  lang: Language;
  onOpenBooking: () => void;
}

export const AppointmentCTA: React.FC<AppointmentCTAProps> = ({ lang, onOpenBooking }) => {
  const t = DICTIONARY[lang];

  return (
    <section className="relative py-24 lg:py-32 bg-[#1C1C1C] overflow-hidden border-b border-white/10">
      {/* Background with Ambient Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1562322140-8baeececf3df?auto=format&fit=crop&w=2000&q=80"
          alt="Hair styling process at Hairdressing Salon Mary"
          className="w-full h-full object-cover object-center filter brightness-50 contrast-[105%]"
          loading="lazy"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/80 to-black/90" />
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Eyebrow */}
        <div className="inline-flex items-center gap-2 mb-4">
          <span className="w-5 h-[1.5px] bg-[#C7A46A]" />
          <span className="text-[10px] uppercase tracking-[0.3em] font-bold text-[#C7A46A]">
            {t.appointmentCta.eyebrow}
          </span>
          <span className="w-5 h-[1.5px] bg-[#C7A46A]" />
        </div>

        {/* Heading */}
        <h2 className="text-3xl sm:text-5xl lg:text-6xl font-serif text-white font-normal leading-[1.08] mb-6 text-balance">
          {t.appointmentCta.heading}
        </h2>

        {/* Supporting text */}
        <p className="text-sm sm:text-base text-[#E8DED2]/85 font-light max-w-2xl mx-auto leading-relaxed mb-10 text-balance">
          {t.appointmentCta.supporting}
        </p>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onOpenBooking}
            id="appointment-cta-primary-btn"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 bg-[#C7A46A] hover:bg-[#B89355] text-white px-8 py-4 text-[10px] uppercase tracking-[0.2em] font-bold transition-all shadow-xs active:scale-[0.98]"
          >
            <Calendar className="w-4 h-4" />
            <span>{t.appointmentCta.primaryBtn}</span>
          </button>

          <a
            href="#contact"
            id="appointment-cta-secondary-btn"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-transparent hover:bg-white hover:text-[#1C1C1C] text-white border border-white/30 px-8 py-4 text-[10px] uppercase tracking-[0.2em] font-bold transition-all"
          >
            <span>{t.appointmentCta.secondaryBtn}</span>
            <ArrowDown className="w-4 h-4 text-[#C7A46A]" />
          </a>
        </div>

        {/* Direct Call Link */}
        <p className="mt-8 text-xs text-[#B7A99A]">
          {lang === 'hr' ? 'Trebate hitan termin ili savjet?' : 'Need an immediate appointment or advice?'}
          {' '}
          <a
            href={`tel:${SALON_INFO.phone.replace(/\s+/g, '')}`}
            className="text-white hover:text-[#C7A46A] underline font-medium transition-colors ml-1"
          >
            {SALON_INFO.displayPhone}
          </a>
        </p>
      </div>
    </section>
  );
};
