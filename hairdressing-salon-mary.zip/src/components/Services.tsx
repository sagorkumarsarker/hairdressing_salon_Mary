import React, { useState } from 'react';
import { Scissors, Sparkles, Feather, Crown, Droplets, ArrowUpRight, HelpCircle, Check, Phone } from 'lucide-react';
import { Language, ServiceItem } from '../types';
import { DICTIONARY, SERVICES_DATA, SALON_INFO } from '../data/salonData';

interface ServicesProps {
  lang: Language;
  onSelectService: (serviceId: string) => void;
}

export const Services: React.FC<ServicesProps> = ({ lang, onSelectService }) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const t = DICTIONARY[lang];

  const getServiceIcon = (iconName: string) => {
    switch (iconName) {
      case 'Scissors':
        return <Scissors className="w-5 h-5" />;
      case 'Sparkles':
        return <Sparkles className="w-5 h-5" />;
      case 'Feather':
        return <Feather className="w-5 h-5" />;
      case 'Crown':
        return <Crown className="w-5 h-5" />;
      case 'Droplets':
      default:
        return <Droplets className="w-5 h-5" />;
    }
  };

  const filteredServices = activeCategory === 'all'
    ? SERVICES_DATA
    : SERVICES_DATA.filter((s) => s.category === activeCategory);

  const categories = [
    { id: 'all', label: t.services.allCategories },
    { id: 'cuts', label: lang === 'hr' ? 'Šišanje & Frizure' : 'Haircuts & Styling' },
    { id: 'grooming', label: lang === 'hr' ? 'Muški Grooming' : "Men's Grooming" },
    { id: 'shaving', label: lang === 'hr' ? 'Brijanje & Brada' : 'Shaving & Beard' },
    { id: 'styling', label: lang === 'hr' ? 'Svečano Stiliziranje' : 'Special Occasions' },
  ];

  return (
    <section id="services" className="py-20 lg:py-28 bg-[#F7F4EF] relative border-b border-[#1C1C1C]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Section */}
        <div className="text-center max-w-3xl mx-auto mb-12 lg:mb-16">
          <div className="inline-flex items-center gap-2 mb-3">
            <span className="w-5 h-[1.5px] bg-[#C7A46A]" />
            <span className="text-[10px] uppercase tracking-[0.3em] font-bold text-[#C7A46A]">
              {t.services.eyebrow}
            </span>
            <span className="w-5 h-[1.5px] bg-[#C7A46A]" />
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-normal text-[#1C1C1C] mb-4">
            {t.services.heading}
          </h2>
          <p className="text-sm sm:text-base text-[#1C1C1C]/65 font-light max-w-2xl mx-auto">
            {t.services.supporting}
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 mb-12">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-5 py-2.5 text-[10px] uppercase tracking-[0.2em] font-bold transition-all ${
                activeCategory === cat.id
                  ? 'bg-[#1C1C1C] text-white shadow-xs'
                  : 'bg-white text-[#1C1C1C]/70 border border-[#1C1C1C]/10 hover:border-[#1C1C1C]'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Service Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {filteredServices.map((service, index) => (
            <div
              key={service.id}
              id={`service-card-${service.id}`}
              className="group bg-white p-8 border border-[#1C1C1C]/10 hover:border-[#1C1C1C] transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Number & Icon Header */}
                <div className="flex items-center justify-between mb-6">
                  <span className="text-xs font-bold text-[#C7A46A] font-serif">
                    {String(index + 1).padStart(2, '0')}
                  </span>
                  <div className="w-10 h-10 bg-[#F7F4EF] group-hover:bg-[#1C1C1C] text-[#1C1C1C] group-hover:text-[#C7A46A] flex items-center justify-center transition-colors">
                    {getServiceIcon(service.iconName)}
                  </div>
                </div>

                {/* Badge if exists */}
                {service.badge && (
                  <span className="inline-block text-[9px] uppercase tracking-[0.2em] font-bold px-2 py-0.5 mb-3 bg-[#F7F4EF] text-[#C7A46A] border border-[#C7A46A]/20">
                    {service.badge[lang]}
                  </span>
                )}

                {/* Service Title */}
                <h3 className="text-xl sm:text-2xl font-serif text-[#1C1C1C] font-normal mb-3 group-hover:text-[#C7A46A] transition-colors">
                  {service.title[lang]}
                </h3>

                {/* Description */}
                <p className="text-xs sm:text-sm text-[#1C1C1C]/65 leading-relaxed mb-6 font-light">
                  {service.description[lang]}
                </p>

                {/* Duration / Feature Note */}
                {service.durationNote && (
                  <div className="flex items-center gap-1.5 text-xs text-[#7A746E] mb-6 pt-3 border-t border-[#1C1C1C]/10">
                    <Check className="w-3.5 h-3.5 text-[#C7A46A]" />
                    <span>{service.durationNote[lang]}</span>
                  </div>
                )}
              </div>

              {/* Card Footer: Pricing Note & Action CTA */}
              <div className="pt-4 border-t border-[#1C1C1C]/10 flex items-center justify-between mt-auto">
                <span className="text-xs text-[#7A746E] italic">
                  {lang === 'hr' ? 'Cijene na upit' : 'Pricing upon request'}
                </span>
                
                <button
                  onClick={() => onSelectService(service.id)}
                  className="inline-flex items-center gap-1.5 text-[10px] uppercase tracking-[0.2em] font-bold text-[#1C1C1C] group-hover:text-[#C7A46A] transition-colors focus:outline-none"
                  aria-label={`Book ${service.title[lang]}`}
                >
                  <span>{t.services.selectService}</span>
                  <ArrowUpRight className="w-4 h-4 transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Pricing Transparency & Consultation Callout Box */}
        <div className="mt-12 p-6 bg-white border border-[#1C1C1C]/10 max-w-2xl mx-auto text-center flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 text-left">
            <div className="w-9 h-9 bg-[#1C1C1C] text-[#C7A46A] flex items-center justify-center shrink-0">
              <HelpCircle className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-[#1C1C1C]">
                {lang === 'hr' ? 'Individualna ponuda & Cjenik' : 'Individual Consultation & Pricing'}
              </p>
              <p className="text-xs text-[#7A746E] mt-0.5">
                {t.services.pricingNotice}
              </p>
            </div>
          </div>

          <a
            href={`tel:${SALON_INFO.phone.replace(/\s+/g, '')}`}
            className="shrink-0 inline-flex items-center gap-2 px-5 py-2.5 border border-[#1C1C1C] text-[10px] uppercase tracking-[0.2em] font-bold text-[#1C1C1C] hover:bg-[#1C1C1C] hover:text-white transition-colors"
          >
            <Phone className="w-3 h-3 text-[#C7A46A]" />
            <span>{SALON_INFO.displayPhone}</span>
          </a>
        </div>

      </div>
    </section>
  );
};
