import React from 'react';
import { MapPin, Clock, Phone, Navigation, AlertCircle, Car } from 'lucide-react';
import { Language } from '../types';
import { DICTIONARY, SALON_INFO } from '../data/salonData';

interface LocationSectionProps {
  lang: Language;
}

export const LocationSection: React.FC<LocationSectionProps> = ({ lang }) => {
  const t = DICTIONARY[lang];

  return (
    <section id="location" className="py-20 lg:py-28 bg-[#F7F4EF] relative border-b border-[#1C1C1C]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 mb-3">
            <span className="w-5 h-[1.5px] bg-[#C7A46A]" />
            <span className="text-[10px] uppercase tracking-[0.3em] font-bold text-[#C7A46A]">
              {t.location.eyebrow}
            </span>
            <span className="w-5 h-[1.5px] bg-[#C7A46A]" />
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-normal text-[#1C1C1C] mb-4">
            {t.location.heading}
          </h2>
        </div>

        {/* Split Screen Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
          
          {/* Left Column: Interactive Map Frame / View */}
          <div className="lg:col-span-7 bg-white border border-[#1C1C1C]/10 overflow-hidden flex flex-col min-h-[420px]">
            {/* Embedded Google Maps iFrame */}
            <div className="relative w-full flex-1 min-h-[360px] bg-[#EFEAE1]">
              <iframe
                title="Hairdressing Salon Mary location in Vinkovci"
                src="https://maps.google.com/maps?q=Duga+ulica+57,+32100,+Vinkovci,+Croatia&t=&z=16&ie=UTF8&iwloc=&output=embed"
                className="w-full h-full border-0 absolute inset-0 filter grayscale-[20%] contrast-[105%]"
                loading="lazy"
                allowFullScreen
                referrerPolicy="no-referrer-when-downgrade"
              />
              
              {/* Floating map marker badge */}
              <div className="absolute top-4 left-4 p-3 bg-white/95 backdrop-blur-md border border-[#1C1C1C]/10 shadow-md flex items-center gap-3 pointer-events-none">
                <div className="w-8 h-8 bg-[#1C1C1C] text-[#C7A46A] flex items-center justify-center font-serif font-bold text-xs">
                  M
                </div>
                <div>
                  <p className="text-xs font-bold uppercase tracking-wider text-[#1C1C1C]">
                    Hairdressing Salon Mary
                  </p>
                  <p className="text-[10px] text-[#7A746E]">
                    Duga ulica 57, Vinkovci
                  </p>
                </div>
              </div>
            </div>

            {/* Map bottom bar */}
            <div className="p-4 bg-[#FDFBF7] border-t border-[#1C1C1C]/10 flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs text-[#55524E]">
                <Car className="w-4 h-4 text-[#C7A46A] shrink-0" />
                <span>{t.location.parkingNote}</span>
              </div>
              <a
                href={SALON_INFO.googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[10px] uppercase tracking-[0.2em] font-bold text-[#1C1C1C] hover:text-[#C7A46A] transition-colors"
              >
                {lang === 'hr' ? 'Otvori u Google Kartama' : 'Open in Google Maps'} →
              </a>
            </div>
          </div>

          {/* Right Column: Address, Hours, Contact Actions */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
            
            {/* Address Card */}
            <div className="bg-white p-7 border border-[#1C1C1C]/10">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-[#F7F4EF] text-[#C7A46A] flex items-center justify-center shrink-0 mt-0.5 border border-[#1C1C1C]/10">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-[10px] uppercase tracking-[0.25em] font-bold text-[#7A746E] mb-1">
                    {t.location.addressTitle}
                  </h3>
                  <p className="text-xl font-serif text-[#1C1C1C] font-normal mb-1">
                    {SALON_INFO.address.street}
                  </p>
                  <p className="text-xs text-[#1C1C1C]/65">
                    {SALON_INFO.address.postalCode} {SALON_INFO.address.city}, Hrvatska / Croatia
                  </p>
                </div>
              </div>
            </div>

            {/* Hours Card */}
            <div className="bg-white p-7 border border-[#1C1C1C]/10">
              <div className="flex items-start gap-4 mb-4">
                <div className="w-10 h-10 bg-[#F7F4EF] text-[#C7A46A] flex items-center justify-center shrink-0 mt-0.5 border border-[#1C1C1C]/10">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-[10px] uppercase tracking-[0.25em] font-bold text-[#7A746E] mb-1">
                    {t.location.hoursTitle}
                  </h3>
                  <p className="text-xs uppercase tracking-wider font-bold text-[#1C1C1C]">
                    {lang === 'hr' ? 'Radno vrijeme' : 'Typical Schedule'}
                  </p>
                </div>
              </div>

              {/* Schedule list */}
              <div className="space-y-2.5 text-xs text-[#1C1C1C]/80 mb-4 pb-4 border-b border-[#1C1C1C]/10">
                {SALON_INFO.hoursSchedule.map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between">
                    <span className="text-[#6B6864]">{item.day[lang]}</span>
                    <span className="font-semibold text-[#1C1C1C]">{item.hours[lang]}</span>
                  </div>
                ))}
              </div>

              {/* Important Verified Notice */}
              <div className="p-3 bg-[#F7F4EF] border border-[#1C1C1C]/10 flex items-start gap-2.5 text-[11px] text-[#6B6864] leading-relaxed">
                <AlertCircle className="w-4 h-4 text-[#C7A46A] shrink-0 mt-0.5" />
                <span>{t.location.hoursWarning}</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <a
                href={SALON_INFO.googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                id="location-directions-btn"
                className="inline-flex items-center justify-center gap-2 bg-[#1C1C1C] hover:bg-[#C7A46A] text-white py-4 px-5 text-[10px] uppercase tracking-[0.2em] font-bold transition-all shadow-xs"
              >
                <Navigation className="w-4 h-4 text-[#C7A46A]" />
                <span>{t.location.getDirections}</span>
              </a>

              <a
                href={`tel:${SALON_INFO.phone.replace(/\s+/g, '')}`}
                id="location-call-btn"
                className="inline-flex items-center justify-center gap-2 border border-[#1C1C1C] text-[#1C1C1C] hover:bg-[#1C1C1C] hover:text-white py-4 px-5 text-[10px] uppercase tracking-[0.2em] font-bold transition-all"
              >
                <Phone className="w-4 h-4" />
                <span>{t.location.callSalon}</span>
              </a>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
