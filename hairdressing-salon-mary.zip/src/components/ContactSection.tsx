import React, { useState } from 'react';
import { Send, CheckCircle2, Phone, Mail, MapPin, Clock, Calendar, AlertCircle } from 'lucide-react';
import { Language, AppointmentFormState } from '../types';
import { DICTIONARY, SALON_INFO, SERVICES_DATA } from '../data/salonData';

interface ContactSectionProps {
  lang: Language;
  preselectedServiceId?: string;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ lang, preselectedServiceId }) => {
  const t = DICTIONARY[lang];

  const [formState, setFormState] = useState<AppointmentFormState>({
    fullName: '',
    contact: '',
    serviceId: preselectedServiceId || '',
    preferredDate: '',
    preferredTime: 'morning',
    message: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formState.fullName.trim() || !formState.contact.trim()) {
      setErrorMsg(lang === 'hr' ? 'Molimo unesite vaše ime i kontakt telefon/email.' : 'Please enter your full name and phone or email.');
      return;
    }

    setErrorMsg(null);
    setIsSubmitting(true);

    // Simulate reliable local processing for concept demonstration
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 600);
  };

  const handleReset = () => {
    setFormState({
      fullName: '',
      contact: '',
      serviceId: '',
      preferredDate: '',
      preferredTime: 'morning',
      message: ''
    });
    setIsSubmitted(false);
  };

  return (
    <section id="contact" className="py-20 lg:py-28 bg-[#F7F4EF] relative border-b border-[#1C1C1C]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 mb-3">
            <span className="w-5 h-[1.5px] bg-[#C7A46A]" />
            <span className="text-[10px] uppercase tracking-[0.3em] font-bold text-[#C7A46A]">
              {t.contact.eyebrow}
            </span>
            <span className="w-5 h-[1.5px] bg-[#C7A46A]" />
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-normal text-[#1C1C1C] mb-4">
            {t.contact.heading}
          </h2>
          <p className="text-sm sm:text-base text-[#1C1C1C]/65 font-light max-w-2xl mx-auto">
            {t.contact.supporting}
          </p>
        </div>

        {/* Two-column layout: Info Card & Appointment Request Form */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          
          {/* Left Column: Business Details & Direct Channels */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-white p-8 border border-[#1C1C1C]/10">
              <span className="text-[10px] uppercase tracking-[0.25em] font-bold text-[#C7A46A] block mb-2">
                Hairdressing Salon Mary
              </span>
              <h3 className="text-2xl font-serif text-[#1C1C1C] font-normal mb-6">
                {lang === 'hr' ? 'Dobrodošli u naš salon' : 'Direct Contact & Inquiries'}
              </h3>

              <div className="space-y-5 text-sm text-[#4A4744]">
                {/* Address */}
                <div className="flex items-start gap-3.5">
                  <div className="w-8 h-8 bg-[#F7F4EF] text-[#C7A46A] flex items-center justify-center shrink-0 mt-0.5 border border-[#1C1C1C]/10">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="font-bold text-xs uppercase tracking-wider text-[#1C1C1C]">{SALON_INFO.address.street}</p>
                    <p className="text-xs text-[#7A746E]">{SALON_INFO.address.postalCode} {SALON_INFO.address.city}, Croatia</p>
                  </div>
                </div>

                {/* Phone */}
                <div className="flex items-start gap-3.5">
                  <div className="w-8 h-8 bg-[#F7F4EF] text-[#C7A46A] flex items-center justify-center shrink-0 mt-0.5 border border-[#1C1C1C]/10">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <a
                      href={`tel:${SALON_INFO.phone.replace(/\s+/g, '')}`}
                      className="font-bold text-xs uppercase tracking-wider text-[#1C1C1C] hover:text-[#C7A46A] transition-colors"
                    >
                      {SALON_INFO.displayPhone}
                    </a>
                    <p className="text-xs text-[#7A746E]">
                      {lang === 'hr' ? 'Poziv za brzi dogovor termina' : 'Call for quick appointment scheduling'}
                    </p>
                  </div>
                </div>

                {/* Location Reference */}
                <div className="flex items-start gap-3.5">
                  <div className="w-8 h-8 bg-[#F7F4EF] text-[#C7A46A] flex items-center justify-center shrink-0 mt-0.5 border border-[#1C1C1C]/10">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="font-bold text-xs uppercase tracking-wider text-[#1C1C1C]">
                      {lang === 'hr' ? 'Termini po dogovoru' : 'Appointments by arrangement'}
                    </p>
                    <p className="text-xs text-[#7A746E]">
                      {lang === 'hr' ? 'Molimo javite se prije dolaska' : 'Please contact salon prior to arrival'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Call button */}
              <div className="mt-8 pt-6 border-t border-[#1C1C1C]/10">
                <a
                  href={`tel:${SALON_INFO.phone.replace(/\s+/g, '')}`}
                  className="w-full inline-flex items-center justify-center gap-2 bg-[#1C1C1C] hover:bg-[#C7A46A] text-white py-4 px-5 text-[10px] uppercase tracking-[0.2em] font-bold transition-all shadow-xs"
                >
                  <Phone className="w-3.5 h-3.5 text-[#C7A46A]" />
                  <span>{lang === 'hr' ? 'Direktan telefonski poziv' : 'Call Salon Directly'}</span>
                </a>
              </div>
            </div>

            {/* Google Rating Mini-Banner */}
            <div className="p-5 bg-white border border-[#1C1C1C]/10 flex items-center gap-4">
              <div className="text-2xl font-serif font-bold text-[#C7A46A]">
                5.0★
              </div>
              <p className="text-xs text-[#1C1C1C]/70">
                {lang === 'hr'
                  ? 'Frizerski salon Mary prepoznat je po pažljivom radu i zadovoljnim klijentima u Vinkovcima.'
                  : 'Salon Mary is trusted for dedicated personal styling in Vinkovci, Croatia.'}
              </p>
            </div>
          </div>

          {/* Right Column: Appointment Request Form */}
          <div className="lg:col-span-7 bg-white p-8 sm:p-10 border border-[#1C1C1C]/10">
            
            {isSubmitted ? (
              <div id="form-success-state" className="py-8 text-center space-y-5 animate-in fade-in duration-300">
                <div className="w-16 h-16 bg-[#F7F4EF] text-[#C7A46A] flex items-center justify-center mx-auto border border-[#C7A46A]/30">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="text-2xl font-serif text-[#1C1C1C]">
                  {t.contact.form.successTitle}
                </h3>
                <p className="text-sm text-[#55524E] max-w-md mx-auto leading-relaxed">
                  {t.contact.form.successMessage}
                </p>

                {/* Submitted summary */}
                <div className="bg-[#F7F4EF] p-4 text-left text-xs space-y-1.5 max-w-md mx-auto text-[#4A4744] border border-[#1C1C1C]/10">
                  <p><strong className="text-[#1C1C1C]">{lang === 'hr' ? 'Ime:' : 'Name:'}</strong> {formState.fullName}</p>
                  <p><strong className="text-[#1C1C1C]">{lang === 'hr' ? 'Kontakt:' : 'Contact:'}</strong> {formState.contact}</p>
                  {formState.preferredDate && <p><strong className="text-[#1C1C1C]">{lang === 'hr' ? 'Datum:' : 'Date:'}</strong> {formState.preferredDate}</p>}
                </div>

                <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
                  <button
                    onClick={handleReset}
                    className="px-6 py-3 border border-[#1C1C1C] text-[10px] uppercase tracking-[0.2em] font-bold text-[#1C1C1C] hover:bg-[#1C1C1C] hover:text-white transition-colors"
                  >
                    {t.contact.form.newRequestBtn}
                  </button>
                  <a
                    href={`tel:${SALON_INFO.phone.replace(/\s+/g, '')}`}
                    className="px-6 py-3 bg-[#C7A46A] text-white text-[10px] uppercase tracking-[0.2em] font-bold hover:bg-[#B89355] transition-colors flex items-center gap-2"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>{SALON_INFO.displayPhone}</span>
                  </a>
                </div>
              </div>
            ) : (
              <form id="appointment-form" onSubmit={handleSubmit} className="space-y-6">
                
                {errorMsg && (
                  <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                {/* Name and Contact in 2 cols */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-[10px] uppercase tracking-[0.2em] font-bold text-[#1C1C1C] mb-2">
                      {t.contact.form.nameLabel}
                    </label>
                    <input
                      type="text"
                      required
                      value={formState.fullName}
                      onChange={(e) => setFormState({ ...formState, fullName: e.target.value })}
                      placeholder={t.contact.form.namePlaceholder}
                      className="w-full px-4 py-3 border border-[#1C1C1C]/15 bg-[#FDFBF7] text-sm text-[#1C1C1C] placeholder:text-[#9E978E] focus:outline-none focus:border-[#1C1C1C]"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase tracking-[0.2em] font-bold text-[#1C1C1C] mb-2">
                      {t.contact.form.contactLabel}
                    </label>
                    <input
                      type="text"
                      required
                      value={formState.contact}
                      onChange={(e) => setFormState({ ...formState, contact: e.target.value })}
                      placeholder={t.contact.form.contactPlaceholder}
                      className="w-full px-4 py-3 border border-[#1C1C1C]/15 bg-[#FDFBF7] text-sm text-[#1C1C1C] placeholder:text-[#9E978E] focus:outline-none focus:border-[#1C1C1C]"
                    />
                  </div>
                </div>

                {/* Service Selection */}
                <div>
                  <label className="block text-[10px] uppercase tracking-[0.2em] font-bold text-[#1C1C1C] mb-2">
                    {t.contact.form.serviceLabel}
                  </label>
                  <select
                    value={formState.serviceId}
                    onChange={(e) => setFormState({ ...formState, serviceId: e.target.value })}
                    className="w-full px-4 py-3 border border-[#1C1C1C]/15 bg-[#FDFBF7] text-sm text-[#1C1C1C] focus:outline-none focus:border-[#1C1C1C]"
                  >
                    <option value="">{t.contact.form.selectServicePrompt}</option>
                    {SERVICES_DATA.map((service) => (
                      <option key={service.id} value={service.id}>
                        {service.title[lang]}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Date & Preferred Time */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-[10px] uppercase tracking-[0.2em] font-bold text-[#1C1C1C] mb-2">
                      {t.contact.form.dateLabel}
                    </label>
                    <input
                      type="date"
                      value={formState.preferredDate}
                      onChange={(e) => setFormState({ ...formState, preferredDate: e.target.value })}
                      className="w-full px-4 py-3 border border-[#1C1C1C]/15 bg-[#FDFBF7] text-sm text-[#1C1C1C] focus:outline-none focus:border-[#1C1C1C]"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase tracking-[0.2em] font-bold text-[#1C1C1C] mb-2">
                      {t.contact.form.timeLabel}
                    </label>
                    <select
                      value={formState.preferredTime}
                      onChange={(e) => setFormState({ ...formState, preferredTime: e.target.value })}
                      className="w-full px-4 py-3 border border-[#1C1C1C]/15 bg-[#FDFBF7] text-sm text-[#1C1C1C] focus:outline-none focus:border-[#1C1C1C]"
                    >
                      <option value="morning">{t.contact.form.morning}</option>
                      <option value="afternoon">{t.contact.form.afternoon}</option>
                      <option value="evening">{t.contact.form.evening}</option>
                    </select>
                  </div>
                </div>

                {/* Message / Notes */}
                <div>
                  <label className="block text-[10px] uppercase tracking-[0.2em] font-bold text-[#1C1C1C] mb-2">
                    {t.contact.form.messageLabel}
                  </label>
                  <textarea
                    rows={3}
                    value={formState.message}
                    onChange={(e) => setFormState({ ...formState, message: e.target.value })}
                    placeholder={t.contact.form.messagePlaceholder}
                    className="w-full px-4 py-3 border border-[#1C1C1C]/15 bg-[#FDFBF7] text-sm text-[#1C1C1C] placeholder:text-[#9E978E] focus:outline-none focus:border-[#1C1C1C]"
                  />
                </div>

                {/* Disclaimer Notice (Strictly required by user prompt) */}
                <div className="p-3.5 bg-[#F7F4EF] border border-[#1C1C1C]/10 flex items-start gap-2.5 text-xs text-[#6B6864] leading-relaxed">
                  <AlertCircle className="w-4 h-4 text-[#C7A46A] shrink-0 mt-0.5" />
                  <span>{t.contact.form.disclaimer}</span>
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  id="submit-appointment-btn"
                  className="w-full inline-flex items-center justify-center gap-2 bg-[#1C1C1C] hover:bg-[#C7A46A] text-white py-4 px-6 text-[10px] uppercase tracking-[0.2em] font-bold transition-all shadow-xs active:scale-[0.99] disabled:opacity-75 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>{isSubmitting ? t.contact.form.submitting : t.contact.form.submitBtn}</span>
                </button>

              </form>
            )}

          </div>

        </div>

      </div>
    </section>
  );
};
