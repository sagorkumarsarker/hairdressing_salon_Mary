import React from 'react';
import { UserCheck, Award, Heart, Sparkles } from 'lucide-react';
import { Language } from '../types';
import { DICTIONARY, EXPERIENCE_PILLARS } from '../data/salonData';

interface ExperienceProps {
  lang: Language;
}

export const Experience: React.FC<ExperienceProps> = ({ lang }) => {
  const t = DICTIONARY[lang];

  const getPillarIcon = (index: number) => {
    switch (index) {
      case 0:
        return <UserCheck className="w-5 h-5 text-[#C7A46A]" />;
      case 1:
        return <Award className="w-5 h-5 text-[#C7A46A]" />;
      case 2:
        return <Heart className="w-5 h-5 text-[#C7A46A]" />;
      case 3:
      default:
        return <Sparkles className="w-5 h-5 text-[#C7A46A]" />;
    }
  };

  return (
    <section id="experience" className="py-20 lg:py-28 bg-[#1C1C1C] text-white relative overflow-hidden border-b border-white/10">
      {/* Subtle Background Accent */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-[#C7A46A]/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-[#C7A46A]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header Section */}
        <div className="text-center max-w-3xl mx-auto mb-16 lg:mb-20">
          <div className="inline-flex items-center gap-2 mb-3">
            <span className="w-5 h-[1.5px] bg-[#C7A46A]" />
            <span className="text-[10px] uppercase tracking-[0.3em] font-bold text-[#C7A46A]">
              {t.experience.eyebrow}
            </span>
            <span className="w-5 h-[1.5px] bg-[#C7A46A]" />
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-normal text-white mb-4">
            {t.experience.heading}
          </h2>
          <p className="text-sm sm:text-base text-[#B7A99A] font-light max-w-2xl mx-auto">
            {t.experience.supporting}
          </p>
        </div>

        {/* 4 Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {EXPERIENCE_PILLARS.map((pillar, idx) => (
            <div
              key={pillar.number}
              id={`experience-pillar-${pillar.number}`}
              className="relative p-8 bg-[#242322] border border-white/10 hover:border-[#C7A46A] transition-all duration-300 group flex flex-col justify-between"
            >
              <div>
                {/* Top Number & Icon */}
                <div className="flex items-center justify-between mb-8">
                  <span className="text-2xl sm:text-3xl font-serif font-light text-[#C7A46A]">
                    {pillar.number}
                  </span>
                  <div className="w-9 h-9 bg-white/5 flex items-center justify-center group-hover:bg-[#C7A46A]/20 transition-colors">
                    {getPillarIcon(idx)}
                  </div>
                </div>

                {/* Title */}
                <h3 className="text-lg sm:text-xl font-serif text-white font-normal mb-3 group-hover:text-[#E8DED2] transition-colors">
                  {pillar.title[lang]}
                </h3>

                {/* Description */}
                <p className="text-xs sm:text-sm text-[#A89F95] leading-relaxed font-light">
                  {pillar.description[lang]}
                </p>
              </div>

              {/* Bottom Decorative Indicator */}
              <div className="mt-8 pt-4 border-t border-white/5">
                <div className="w-0 group-hover:w-full h-[1.5px] bg-[#C7A46A] transition-all duration-500 ease-out" />
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
