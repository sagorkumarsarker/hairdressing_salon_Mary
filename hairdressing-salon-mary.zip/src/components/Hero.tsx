import React from 'react';
import { Calendar, ArrowRight, ChevronDown, MapPin, Sparkles } from 'lucide-react';
import { Language } from '../types';
import { DICTIONARY, SALON_INFO } from '../data/salonData';

interface HeroProps {
  lang: Language;
  onOpenBooking: () => void;
}

export const Hero: React.FC<HeroProps> = ({ lang, onOpenBooking }) => {
  const t = DICTIONARY[lang];

  return (
    <section id="home" className="relative pt-20 bg-[#F7F4EF] text-[#1C1C1C] overflow-hidden border-b border-[#1C1C1C]/10">
      {/* Main Hero Container with Vertical Rail & Split Columns */}
      <div className="flex flex-col lg:flex-row min-h-[calc(100vh-5rem)]">
        
        {/* Left Architectural Vertical Rail (Desktop) */}
        <div className="hidden lg:flex w-16 border-r border-[#1C1C1C]/10 items-center justify-center shrink-0 bg-[#F7F4EF]">
          <span className="rotate-[-90deg] whitespace-nowrap text-[10px] tracking-[0.5em] text-[#B7A99A] uppercase font-semibold">
            Vinkovci • Croatia
          </span>
        </div>

        {/* Content Area */}
        <div className="flex-1 flex flex-col lg:flex-row">
          
          {/* Left Column: Typography & CTAs */}
          <div className="w-full lg:w-1/2 flex flex-col justify-center px-6 sm:px-12 lg:px-16 py-12 lg:py-16 relative bg-[#a0a0a0]">
            {/* Top Tag */}
            <div className="flex items-center gap-2 mb-4">
              <span className="w-5 h-[1.5px] bg-[#C7A46A]" />
              <span className="text-[10px] uppercase tracking-[0.3em] text-[#99831a] font-bold">
                {t.hero.salonTitle}
              </span>
            </div>

            {/* Main Headline */}
            <h1
              id="hero-headline"
              className="text-4xl sm:text-6xl xl:text-7xl font-serif text-[#1C1C1C] font-normal leading-[1.02] tracking-tight mb-6 text-balance"
            >
              {lang === 'hr' ? (
                <>
                  Stil koji pristaje <br />
                  <span className="italic text-[#C7A46A] bg-[#111100]">upravo vama.</span>
                </>
              ) : (
                <>
                  Style That <br />
                  Feels Like <span className="italic text-[#C7A46A] bg-[#111100]">You.</span>
                </>
              )}
            </h1>

            {/* Supporting Paragraph */}
            <p
              id="hero-supporting-text"
              className="text-sm sm:text-base text-[#1C1C1C]/65 font-light leading-relaxed max-w-md mb-8 sm:mb-10 text-balance"
            >
              {t.hero.supporting}
            </p>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-4 sm:gap-6 mb-10">
              <button
                id="hero-primary-cta"
                onClick={onOpenBooking}
                className="px-7 py-3.5 sm:px-8 sm:py-4 bg-[#1C1C1C] text-white text-[10px] uppercase tracking-[0.2em] font-bold hover:bg-[#C7A46A] transition-all shadow-xs active:scale-[0.98]"
              >
                {t.hero.primaryCTA}
              </button>

              <a
                id="hero-secondary-cta"
                href="#services"
                className="px-7 py-3.5 sm:px-8 sm:py-4 border border-[#1C1C1C] text-[#1C1C1C] text-[10px] uppercase tracking-[0.2em] font-bold hover:bg-[#1C1C1C] hover:text-white transition-all"
              >
                {t.hero.secondaryCTA}
              </a>

              <a
                href="#about"
                className="text-[10px] uppercase tracking-[0.18em] font-semibold border-b border-[#C7A46A] pb-0.5 text-[#1C1C1C] hover:text-[#C7A46A] transition-colors inline-flex items-center gap-1.5"
              >
                <span>{lang === 'hr' ? 'Upoznajte salon →' : 'Meet the Stylist →'}</span>
              </a>
            </div>

            {/* Key Micro Badges */}
            <div className="pt-6 border-t border-[#1C1C1C]/10 flex flex-wrap items-center gap-6 text-[11px] text-[#7A746E]">
              <div className="flex items-center gap-2">
                <span className="font-serif text-sm font-semibold text-[#1C1C1C]">1:1</span>
                <span>{lang === 'hr' ? 'Individualan rad' : '1:1 Personal Focus'}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-serif text-sm font-semibold text-[#C7A46A]">5.0 ★</span>
                <span>{lang === 'hr' ? 'Google Ocjena' : 'Google Rating'}</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#C7A46A]" />
                <span>Duga ulica 57, Vinkovci</span>
              </div>
            </div>
          </div>

          {/* Right Column: Editorial Image & Overlay Card */}
          <div className="w-full lg:w-1/2 bg-[#E8DED2] relative flex items-center justify-center p-6 sm:p-10 lg:p-14 border-t lg:border-t-0 lg:border-l border-[#1C1C1C]/10">
            <div className="w-full h-full min-h-[380px] lg:min-h-[500px] border border-[#1C1C1C]/10 relative overflow-hidden bg-[#D8CEBE]">
              <img
                src="https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=1600&q=85"
                alt="Hairdressing Salon Mary interior in Vinkovci"
                className="w-full h-full object-cover object-center filter contrast-[105%]"
                loading="eager"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-black/10" />

              {/* High-Contrast Overlay Label Card */}
              <div className="absolute bottom-6 right-6 sm:bottom-8 sm:right-8 bg-[#1C1C1C] text-white p-5 sm:p-6 w-56 sm:w-64 shadow-2xl border border-white/10">
                <span className="block text-[8px] uppercase tracking-[0.25em] text-[#B7A99A] mb-2 font-semibold">
                  Salon Interior • Vinkovci
                </span>
                <p className="text-xs sm:text-sm font-serif italic text-white/90 leading-snug">
                  {lang === 'hr'
                    ? '„Mjesto za vrhunsku frizuru i pozitivnu energiju.”'
                    : '“A place for great hair and good energy.”'}
                </p>
                <p className="text-[9px] text-[#A89F95] mt-2 uppercase tracking-widest">
                  Duga ulica 57
                </p>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Bottom Service Summary Grid (Artistic Flair 4-Column Bar) */}
      <div className="border-t border-[#1C1C1C]/10 bg-white grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
        {/* Item 01 */}
        <div className="border-b sm:border-b-0 sm:border-r border-[#1C1C1C]/10 p-6 sm:p-8 flex flex-col justify-between hover:bg-[#F7F4EF] transition-colors group">
          <span className="text-xs font-bold text-[#C7A46A] font-serif mb-4">01</span>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-widest mb-1 text-[#1C1C1C]">
              {lang === 'hr' ? 'Šišanje & Stiliziranje' : 'Haircuts & Styling'}
            </h3>
            <p className="text-[11px] text-[#1C1C1C]/60 font-light">
              {lang === 'hr' ? 'Prilagođena preciznost za svako lice.' : 'Tailored precision for every face.'}
            </p>
          </div>
        </div>

        {/* Item 02 */}
        <div className="border-b sm:border-b-0 lg:border-r border-[#1C1C1C]/10 p-6 sm:p-8 flex flex-col justify-between hover:bg-[#F7F4EF] transition-colors">
          <span className="text-xs font-bold text-[#C7A46A] font-serif mb-4">02</span>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-widest mb-1 text-[#1C1C1C]">
              {lang === 'hr' ? 'Muški Grooming' : "Men's Grooming"}
            </h3>
            <p className="text-[11px] text-[#1C1C1C]/60 font-light">
              {lang === 'hr' ? 'Moderne tehnike i klasična njega.' : 'Modern techniques, classic care.'}
            </p>
          </div>
        </div>

        {/* Item 03 */}
        <div className="border-b sm:border-b-0 sm:border-r border-[#1C1C1C]/10 p-6 sm:p-8 flex flex-col justify-between hover:bg-[#F7F4EF] transition-colors">
          <span className="text-xs font-bold text-[#C7A46A] font-serif mb-4">03</span>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-widest mb-1 text-[#1C1C1C]">
              {lang === 'hr' ? 'Brada & Brijanje' : 'Beard & Shave'}
            </h3>
            <p className="text-[11px] text-[#1C1C1C]/60 font-light">
              {lang === 'hr' ? 'Stručna njega na adresi Duga ulica 57.' : 'Expert grooming at Duga ulica 57.'}
            </p>
          </div>
        </div>

        {/* Item 04: Dark Tile */}
        <div className="bg-[#1C1C1C] p-6 sm:p-8 flex flex-col justify-between text-white">
          <div className="flex justify-between items-start mb-4">
            <span className="text-[10px] font-bold text-[#C7A46A] tracking-[0.2em] uppercase">
              {lang === 'hr' ? 'LOKACIJA' : 'LOCATION'}
            </span>
            <MapPin className="w-4 h-4 text-[#C7A46A]" />
          </div>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-widest mb-1 text-white">
              Vinkovci, Croatia
            </h3>
            <p className="text-[11px] text-white/60">
              Duga ulica 57, 32100
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
