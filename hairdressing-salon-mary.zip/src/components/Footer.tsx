import React from 'react';
import { MapPin, Phone, ExternalLink, Heart } from 'lucide-react';
import { Language } from '../types';
import { DICTIONARY, SALON_INFO } from '../data/salonData';

interface FooterProps {
  lang: Language;
  onOpenBooking: () => void;
}

export const Footer: React.FC<FooterProps> = ({ lang, onOpenBooking }) => {
  const t = DICTIONARY[lang];

  return (
    <footer id="main-footer" className="bg-[#1C1C1C] text-[#E8DED2] border-t border-white/10 pt-16 pb-24 sm:pb-16 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 lg:gap-16 pb-12 border-b border-white/10">
          
          {/* Brand & Narrative */}
          <div className="md:col-span-5 space-y-4">
            <a href="#home" className="inline-block group">
              <span className="text-2xl sm:text-3xl font-serif tracking-[0.2em] font-normal text-white">
                MARY
              </span>
              <span className="block text-[8px] sm:text-[9px] tracking-[0.3em] uppercase text-[#C7A46A] -mt-0.5 font-bold">
                Hairdressing Salon • Vinkovci
              </span>
            </a>

            <p className="text-xs sm:text-sm text-[#A89F95] font-light max-w-sm leading-relaxed">
              {t.footer.tagline}
            </p>

            <div className="pt-2">
              <p className="text-xs text-[#7A746E]">
                {SALON_INFO.hoursNotice[lang]}
              </p>
            </div>
          </div>

          {/* Quick Links */}
          <div className="md:col-span-3 space-y-4">
            <h4 className="text-[10px] uppercase tracking-[0.25em] font-bold text-[#C7A46A]">
              {t.footer.quickLinks}
            </h4>
            <ul className="space-y-2.5 text-xs text-[#A89F95]">
              <li>
                <a href="#home" className="hover:text-[#C7A46A] transition-colors">{t.nav.home}</a>
              </li>
              <li>
                <a href="#about" className="hover:text-[#C7A46A] transition-colors">{t.nav.about}</a>
              </li>
              <li>
                <a href="#services" className="hover:text-[#C7A46A] transition-colors">{t.nav.services}</a>
              </li>
              <li>
                <a href="#experience" className="hover:text-[#C7A46A] transition-colors">{t.nav.experience}</a>
              </li>
              <li>
                <a href="#gallery" className="hover:text-[#C7A46A] transition-colors">{t.nav.gallery}</a>
              </li>
              <li>
                <a href="#reviews" className="hover:text-[#C7A46A] transition-colors">{t.nav.reviews}</a>
              </li>
              <li>
                <a href="#location" className="hover:text-[#C7A46A] transition-colors">{t.nav.location}</a>
              </li>
            </ul>
          </div>

          {/* Contact Details & Maps Link */}
          <div className="md:col-span-4 space-y-4">
            <h4 className="text-[10px] uppercase tracking-[0.25em] font-bold text-[#C7A46A]">
              {t.footer.contactInfo}
            </h4>
            
            <div className="space-y-3 text-xs text-[#A89F95]">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#C7A46A] shrink-0 mt-0.5" />
                <span>{SALON_INFO.address.fullFormatted}</span>
              </div>

              <div className="flex items-start gap-2.5">
                <Phone className="w-4 h-4 text-[#C7A46A] shrink-0 mt-0.5" />
                <a
                  href={`tel:${SALON_INFO.phone.replace(/\s+/g, '')}`}
                  className="hover:text-white transition-colors"
                >
                  {SALON_INFO.displayPhone}
                </a>
              </div>
            </div>

            <div className="pt-2">
              <a
                href={SALON_INFO.googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-xs text-[#C7A46A] hover:underline"
              >
                <span>Google Maps Vinkovci</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            <div className="pt-2">
              <button
                onClick={onOpenBooking}
                className="inline-flex items-center gap-2 bg-[#C7A46A] hover:bg-[#B89355] text-white px-6 py-3 text-[10px] uppercase tracking-[0.2em] font-bold transition-all shadow-xs"
              >
                <span>{t.nav.bookAppointment}</span>
              </button>
            </div>
          </div>

        </div>

        {/* Bottom copyright row */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#7A746E]">
          <p>© 2026 Hairdressing Salon Mary. {t.footer.rights}</p>
          <p className="flex items-center gap-1">
            <span>{t.footer.designedFor}</span>
          </p>
        </div>

      </div>
    </footer>
  );
};
