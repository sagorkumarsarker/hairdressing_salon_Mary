import React, { useState, useEffect, useCallback } from 'react';
import { Maximize2, X, ChevronLeft, ChevronRight, Eye } from 'lucide-react';
import { Language, GalleryImage } from '../types';
import { DICTIONARY, GALLERY_IMAGES } from '../data/salonData';

interface GalleryProps {
  lang: Language;
}

export const Gallery: React.FC<GalleryProps> = ({ lang }) => {
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [selectedImageIndex, setSelectedImageIndex] = useState<number | null>(null);
  const t = DICTIONARY[lang];

  const filteredImages = activeFilter === 'all'
    ? GALLERY_IMAGES
    : GALLERY_IMAGES.filter((img) => img.category === activeFilter);

  const filters = [
    { id: 'all', label: t.gallery.filters.all },
    { id: 'interior', label: t.gallery.filters.interior },
    { id: 'styling', label: t.gallery.filters.styling },
    { id: 'grooming', label: t.gallery.filters.grooming },
    { id: 'details', label: t.gallery.filters.details },
  ];

  // Lightbox handlers
  const handleNext = useCallback(() => {
    if (selectedImageIndex === null) return;
    setSelectedImageIndex((prev) => (prev! + 1) % filteredImages.length);
  }, [selectedImageIndex, filteredImages.length]);

  const handlePrev = useCallback(() => {
    if (selectedImageIndex === null) return;
    setSelectedImageIndex((prev) => (prev! - 1 + filteredImages.length) % filteredImages.length);
  }, [selectedImageIndex, filteredImages.length]);

  const handleClose = useCallback(() => {
    setSelectedImageIndex(null);
  }, []);

  // Keyboard navigation for Lightbox
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (selectedImageIndex === null) return;
      if (e.key === 'Escape') handleClose();
      if (e.key === 'ArrowRight') handleNext();
      if (e.key === 'ArrowLeft') handlePrev();
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedImageIndex, handleClose, handleNext, handlePrev]);

  return (
    <section id="gallery" className="py-20 lg:py-28 bg-[#F7F4EF] relative border-b border-[#1C1C1C]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 mb-3">
            <span className="w-5 h-[1.5px] bg-[#C7A46A]" />
            <span className="text-[10px] uppercase tracking-[0.3em] font-bold text-[#C7A46A]">
              {t.gallery.eyebrow}
            </span>
            <span className="w-5 h-[1.5px] bg-[#C7A46A]" />
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-normal text-[#1C1C1C] mb-4">
            {t.gallery.heading}
          </h2>
          <p className="text-sm sm:text-base text-[#1C1C1C]/65 font-light max-w-2xl mx-auto">
            {t.gallery.supporting}
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 mb-10">
          {filters.map((f) => (
            <button
              key={f.id}
              onClick={() => {
                setActiveFilter(f.id);
                setSelectedImageIndex(null);
              }}
              className={`px-5 py-2.5 text-[10px] uppercase tracking-[0.2em] font-bold transition-all ${
                activeFilter === f.id
                  ? 'bg-[#1C1C1C] text-white shadow-xs'
                  : 'bg-white text-[#1C1C1C]/70 border border-[#1C1C1C]/10 hover:border-[#1C1C1C]'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {filteredImages.map((image, index) => (
            <div
              key={image.id}
              onClick={() => setSelectedImageIndex(index)}
              className={`group relative overflow-hidden bg-[#E8DED2] cursor-pointer border border-[#1C1C1C]/10 transition-all duration-300 ${
                image.aspectRatio === 'tall'
                  ? 'sm:row-span-2 aspect-[3/4] sm:aspect-auto'
                  : image.aspectRatio === 'wide'
                  ? 'sm:col-span-2 aspect-[16/9]'
                  : 'aspect-square'
              }`}
            >
              <img
                src={image.url}
                alt={image.alt[lang]}
                className="w-full h-full object-cover object-center filter contrast-[102%] group-hover:scale-105 transition-transform duration-700 ease-out"
                loading="lazy"
                referrerPolicy="no-referrer"
              />
              
              {/* Overlay on Hover */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-5 text-white">
                <div className="transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                  <div className="w-8 h-8 bg-white/20 backdrop-blur-md flex items-center justify-center mb-2 text-white">
                    <Maximize2 className="w-4 h-4" />
                  </div>
                  <p className="text-xs font-serif italic font-light text-[#E8DED2]">
                    {image.caption[lang]}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Lightbox Modal */}
      {selectedImageIndex !== null && filteredImages[selectedImageIndex] && (
        <div
          id="gallery-lightbox"
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-8"
          onClick={handleClose}
          role="dialog"
          aria-modal="true"
          aria-label="Gallery Lightbox"
        >
          {/* Close button */}
          <button
            onClick={handleClose}
            className="absolute top-6 right-6 z-50 p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors focus:outline-none focus:ring-2 focus:ring-[#C7A46A]"
            aria-label={t.gallery.close}
          >
            <X className="w-6 h-6" />
          </button>

          {/* Prev button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              handlePrev();
            }}
            className="absolute left-4 sm:left-8 top-1/2 -translate-y-1/2 z-50 p-3 rounded-full bg-white/10 hover:bg-white/25 text-white transition-colors focus:outline-none focus:ring-2 focus:ring-[#C7A46A]"
            aria-label={t.gallery.prev}
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          {/* Next button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleNext();
            }}
            className="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 z-50 p-3 rounded-full bg-white/10 hover:bg-white/25 text-white transition-colors focus:outline-none focus:ring-2 focus:ring-[#C7A46A]"
            aria-label={t.gallery.next}
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Content */}
          <div
            className="relative max-w-5xl max-h-[85vh] flex flex-col items-center"
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={filteredImages[selectedImageIndex].url}
              alt={filteredImages[selectedImageIndex].alt[lang]}
              className="max-h-[75vh] w-auto object-contain rounded-sm shadow-2xl"
              referrerPolicy="no-referrer"
            />
            <div className="mt-4 text-center text-white">
              <p className="text-sm font-serif text-[#E8DED2]">
                {filteredImages[selectedImageIndex].caption[lang]}
              </p>
              <p className="text-xs text-white/50 mt-1">
                {selectedImageIndex + 1} / {filteredImages.length}
              </p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
