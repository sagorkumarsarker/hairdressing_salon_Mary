import React, { useState, useEffect } from 'react';
import { Menu, X, Phone, Calendar, Globe, MapPin } from 'lucide-react';
import { Language } from '../types';
import { DICTIONARY, SALON_INFO } from '../data/salonData';

interface NavbarProps {
  lang: Language;
  onToggleLang: () => void;
  onOpenBooking: (serviceId?: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ lang, onToggleLang, onOpenBooking }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const t = DICTIONARY[lang];

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { href: '#home', label: t.nav.home },
    { href: '#about', label: t.nav.about },
    { href: '#services', label: t.nav.services },
    { href: '#experience', label: t.nav.experience },
    { href: '#gallery', label: t.nav.gallery },
    { href: '#reviews', label: t.nav.reviews },
    { href: '#location', label: t.nav.location },
    { href: '#contact', label: t.nav.contact },
  ];

  return (
    <>
      <header
        id="main-header"
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#F7F4EF]/95 backdrop-blur-md shadow-xs border-b border-[#1C1C1C]/10 py-3.5 text-[#1C1C1C]'
            : 'bg-white/60 backdrop-blur-md border-b border-[#1C1C1C]/10 py-4 text-[#1C1C1C]'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          {/* Logo / Brand Name */}
          <a
            href="#home"
            id="brand-logo"
            className="group flex flex-col focus:outline-none focus-visible:ring-1 focus-visible:ring-[#C7A46A]"
          >
            <span className="text-2xl sm:text-3xl font-serif tracking-[0.2em] font-bold text-[#1C1C1C] transition-colors">
              MARY
            </span>
            <span className="text-[8px] sm:text-[9px] tracking-[0.4em] text-[#B7A99A] uppercase -mt-1 font-medium transition-colors">
              Hairdressing Salon
            </span>
          </a>

          {/* Desktop Navigation */}
          <nav id="desktop-nav" aria-label="Main Navigation" className="hidden lg:flex items-center space-x-8">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-[11px] uppercase tracking-widest font-semibold text-[#1C1C1C]/70 hover:text-[#C7A46A] transition-colors relative py-1 focus:outline-none focus-visible:ring-1 focus-visible:ring-[#C7A46A]"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Right Action buttons */}
          <div className="hidden sm:flex items-center space-x-4">
            {/* Language Switcher */}
            <button
              id="lang-toggle-btn"
              onClick={onToggleLang}
              className="flex items-center gap-1.5 px-3 py-1.5 text-[10px] uppercase tracking-[0.2em] font-semibold border border-[#1C1C1C]/15 text-[#1C1C1C]/80 hover:border-[#C7A46A] hover:text-[#C7A46A] transition-colors"
              title={lang === 'hr' ? 'Switch to English' : 'Prebaci na hrvatski'}
              aria-label={`Language selector. Current: ${lang.toUpperCase()}`}
            >
              <Globe className="w-3 h-3 text-[#C7A46A]" />
              <span>{lang === 'hr' ? 'EN' : 'HR'}</span>
            </button>

            {/* Direct Phone link */}
            <a
              href={`tel:${SALON_INFO.phone.replace(/\s+/g, '')}`}
              id="nav-phone-link"
              className="flex items-center gap-1.5 text-xs font-medium tracking-wide text-[#1C1C1C]/80 hover:text-[#C7A46A] transition-colors"
              title={`Call ${SALON_INFO.displayPhone}`}
            >
              <Phone className="w-3.5 h-3.5 text-[#C7A46A]" />
              <span className="hidden xl:inline">{SALON_INFO.displayPhone}</span>
            </a>

            {/* Book Appointment CTA */}
            <button
              id="nav-book-btn"
              onClick={() => onOpenBooking()}
              className="inline-flex items-center gap-2 bg-[#1C1C1C] text-white hover:bg-[#C7A46A] px-6 py-3 text-[10px] uppercase tracking-[0.2em] font-bold transition-all shadow-xs active:scale-[0.98] focus:outline-none focus:ring-1 focus:ring-[#C7A46A]"
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>{t.nav.bookAppointment}</span>
            </button>
          </div>

          {/* Mobile menu button */}
          <div className="flex items-center gap-2 lg:hidden">
            <button
              id="mobile-lang-toggle"
              onClick={onToggleLang}
              className="p-1.5 text-xs font-semibold uppercase text-[#1C1C1C] hover:text-[#C7A46A]"
              aria-label="Toggle language"
            >
              {lang === 'hr' ? 'EN' : 'HR'}
            </button>

            <button
              id="mobile-menu-trigger"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-[#1C1C1C] hover:text-[#C7A46A] focus:outline-none"
              aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div
          id="mobile-drawer"
          className="fixed inset-0 z-50 lg:hidden bg-black/60 backdrop-blur-sm transition-opacity"
          onClick={() => setMobileMenuOpen(false)}
        >
          <div
            className="fixed inset-y-0 right-0 w-full max-w-xs bg-[#F7F4EF] shadow-2xl p-6 flex flex-col justify-between border-l border-[#1C1C1C]/10"
            onClick={(e) => e.stopPropagation()}
          >
            <div>
              <div className="flex items-center justify-between pb-6 border-b border-[#1C1C1C]/10">
                <div>
                  <span className="text-2xl font-serif tracking-[0.2em] font-bold text-[#1C1C1C]">
                    MARY
                  </span>
                  <span className="block text-[8px] tracking-[0.4em] uppercase text-[#B7A99A]">
                    Hairdressing Salon
                  </span>
                </div>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-2 text-[#1C1C1C] hover:text-[#C7A46A]"
                  aria-label="Close menu"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="py-6 flex flex-col space-y-4">
                {navLinks.map((link) => (
                  <a
                    key={link.href}
                    href={link.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className="text-sm uppercase tracking-widest font-semibold text-[#1C1C1C] hover:text-[#C7A46A] py-1 transition-colors"
                  >
                    {link.label}
                  </a>
                ))}
              </div>
            </div>

            <div className="pt-6 border-t border-[#1C1C1C]/10 space-y-4">
              <div className="flex items-center gap-2 text-xs text-[#7A746E]">
                <MapPin className="w-4 h-4 text-[#C7A46A] shrink-0" />
                <span>{SALON_INFO.address.fullFormatted}</span>
              </div>

              <a
                href={`tel:${SALON_INFO.phone.replace(/\s+/g, '')}`}
                className="flex items-center justify-center gap-2 w-full py-3 px-4 border border-[#1C1C1C]/15 text-[10px] uppercase tracking-[0.2em] font-bold text-[#1C1C1C] hover:bg-white transition-colors"
              >
                <Phone className="w-3.5 h-3.5 text-[#C7A46A]" />
                <span>{SALON_INFO.displayPhone}</span>
              </a>

              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenBooking();
                }}
                className="w-full flex items-center justify-center gap-2 bg-[#1C1C1C] hover:bg-[#C7A46A] text-white py-3.5 px-4 text-[10px] uppercase tracking-[0.2em] font-bold shadow-xs transition-colors"
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>{t.nav.bookAppointment}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
